using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using HistoricalAtlas.Components.Shared;
using HistoricalAtlas.Domain;
using HistoricalAtlas.Services;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.FileProviders;
using Microsoft.AspNetCore.DataProtection;
Environment.SetEnvironmentVariable("ATLAS_BOOTSTRAP_PASSWORD", Guid.NewGuid().ToString("N"));
int checks = 0;
void Equal(decimal actual, decimal expected, string name) { if(actual != expected) throw new Exception($"{name}: expected {expected}, got {actual}"); checks++; }
AtlasSnapshot Data() => new() {
 Years = [2000,2001,2002,2003],
 Plans = [new(){CountryId=1,EquipmentId=1,StartYear=2000,StartingStock=100,AnnualRaw=10}],
 ResourcePlans = [new(){CountryId=1,ResourceId=1,StartYear=2000,StartingStock=100,AnnualIncome=15,AnnualUsage=5}]
};
GlobalEffect Effect(string domain, string mode, decimal value, int stage=1, string scope="Annual") => new(){Name="Test",TargetDomain=domain,ValueMode=mode,Percent=value,Stage=stage,TargetKind=scope,EquipmentIds=[1],ResourceIds=[1]};
foreach(var domain in new[]{"Equipment","Resource"}) {
 decimal Stock(AtlasSnapshot d,int year) => domain == "Equipment" ? AtlasCalculator.Calculate(d,1,1,year).Stock : ResourceCalculator.Calculate(d,1,1,year).Stock;
 foreach(var stage in new[]{1,2}) foreach(var scope in new[]{"Annual","Stock"}) foreach(var value in new[]{20m,-20m}) {
  var d=Data(); d.GlobalEffects=[Effect(domain,"Fixed",value,stage,scope)];
  Equal(Stock(d,2000),100,$"{domain} initial {stage}/{scope}");
  Equal(Stock(d,2001),110+value,$"{domain} signed {value} {stage}/{scope}");
  Equal(Stock(d,2002),120+2*value,$"{domain} recurrent {stage}/{scope}");
 }
 var mixed=Data(); mixed.GlobalEffects=[Effect(domain,"Percent",50),Effect(domain,"Fixed",5),Effect(domain,"Percent",100,2),Effect(domain,"Fixed",-3,2)];
 Equal(Stock(mixed,2001),137,$"{domain} stage order");
 var restricted=Data();var e=Effect(domain,"Fixed",20);e.CountryIds=[2];restricted.GlobalEffects=[e];Equal(Stock(restricted,2001),110,$"{domain} country filter");
 e.CountryIds=[];e.FromYear=2002;e.ToYear=2002;Equal(Stock(restricted,2001),110,$"{domain} from year");Equal(Stock(restricted,2003),150,$"{domain} end year");
 e.EquipmentIds=[];e.ResourceIds=[];Equal(Stock(restricted,2002),120,$"{domain} target filter");
 var linked=Data(); var source=Effect(domain,"CategoryStock",10);source.SourceCategories=[new(){CountryId=0,EquipmentId=1}];linked.GlobalEffects=[source];Equal(Stock(linked,2001),120,$"{domain} legacy stock linked");
}
var auditData=Data();auditData.GlobalEffects=[Effect("Equipment","Fixed",5)];var audit=HistoricalDevianceCalculator.Calculate(auditData,1,1,2001)!;
Equal(audit.ProductionAdjustment,5,"audit fixed impact");if(audit.AppliedEffects.Single().Kind!="Fixed")throw new Exception("audit fixed label");checks++;
var rateData=Data();var rate=Effect("Resource","EquipmentRate",-2);rate.SourceCategories=[new(){CountryId=0,EquipmentId=1}];rateData.GlobalEffects=[rate];Equal(ResourceCalculator.Calculate(rateData,1,1,2001).Stock,90,"legacy equipment rate");
rate.ValueMode="EquipmentAnnual";rate.Percent=-10;Equal(ResourceCalculator.Calculate(rateData,1,1,2001).Stock,109,"legacy equipment percent");
// Verify SQLite save/reload, including existing calculation modes.
var testRoot=Path.Combine(Path.GetTempPath(),"effect-db-"+Guid.NewGuid());Directory.CreateDirectory(testRoot);
try {
 var host=new TestHost{ContentRootPath=testRoot};
 var accounts=new AccountStore(host,new EphemeralDataProtectionProvider());accounts.Initialize();
 var catalog=new ScenarioCatalog(host,accounts);catalog.Initialize();catalog.Create("Test scenario","test","test");
 using var db=new AtlasStore(catalog,accounts,"test");db.Initialize();
 db.SaveCountry(new(){Name="Test country"});db.SaveCategory(new(){Name="Test category"});var snapshot=db.Snapshot();
 db.SaveEquipment(new(){Name="Tank",CategoryId=snapshot.Categories.Single().Id});snapshot=db.Snapshot();
 foreach(var domain in new[]{"Equipment","Resource"}) foreach(var mode in new[]{"Fixed","Percent","CategoryStock","EquipmentAnnual","EquipmentRate"}) {
  if(domain=="Equipment" && mode is "EquipmentAnnual" or "EquipmentRate") continue;
  var effect=Effect(domain,mode,-12.5m);effect.EquipmentIds=[snapshot.Equipment.Single().Id];effect.ResourceIds=[snapshot.Resources.First().Id];effect.SourceCategories=mode is "Fixed" or "Percent" ? [] : [new(){EquipmentId=snapshot.Equipment.Single().Id}];
  db.SaveGlobalEffect(effect);var saved=db.Snapshot().GlobalEffects.Last();Equal(saved.Percent,-12.5m,$"persist {domain}/{mode}");if(saved.ValueMode!=mode)throw new Exception("mode lost");
 }
} finally {Directory.Delete(testRoot,true);}
Console.WriteLine($"PASS: {checks} calculation, scope, audit, legacy-mode and persistence checks");
// Render the resource report to verify filtering, units, descriptions and forecast privacy.
var renderedData=Data();renderedData.Countries=[new(){Id=1,Name="Country one"}];renderedData.Resources=[new(){Id=1,Name="Oil",Unit="barrels"}];
var visible=Effect("Resource","Fixed",-200.5m);visible.Name="Visible fixed resource";visible.Description="Resource description";
var hiddenEquipment=Effect("Equipment","Percent",10);hiddenEquipment.Name="Hidden equipment effect";
var hiddenCountry=Effect("Resource","Percent",10);hiddenCountry.Name="Hidden country effect";hiddenCountry.CountryIds=[2];
var hiddenDate=Effect("Resource","Percent",10);hiddenDate.Name="Hidden future effect";hiddenDate.FromYear=2020;
renderedData.GlobalEffects=[visible,hiddenEquipment,hiddenCountry,hiddenDate];
var services=new ServiceCollection().AddLogging().AddSingleton<IJSRuntime,NoopJS>().BuildServiceProvider();
await using(var renderer=new HtmlRenderer(services,services.GetRequiredService<ILoggerFactory>())) {
 async Task<string> Render(bool manager) => await renderer.Dispatcher.InvokeAsync(async()=>{
  var component=await renderer.RenderComponentAsync<ResourceReport>(ParameterView.FromDictionary(new Dictionary<string,object?>{{"Data",renderedData},{"CountryId",1},{"Year",2000},{"IsManager",manager}}));return component.ToHtmlString();
 });
 void Contains(string html,string expected,bool present) {if(html.Contains(expected)!=present)throw new Exception($"Resource panel rendering: {expected}, expected present={present}");checks++;}
 var html=await Render(false);Contains(html,"Applied global effects",true);Contains(html,visible.Name,true);Contains(html,"200.50 barrels",true);Contains(html,visible.Description,true);
 foreach(var hidden in new[]{hiddenEquipment,hiddenCountry,hiddenDate})Contains(html,hidden.Name,false);
 renderedData.PrivateYears=[2001];html=await Render(false);Contains(html,visible.Name,false);Contains(html,"Effects for this private date",true);
 html=await Render(true);Contains(html,visible.Name,true);
}
Console.WriteLine($"PASS: {checks} total checks including resource-panel rendering and forecast privacy");
class TestHost : IHostEnvironment {
 public string EnvironmentName {get;set;}="Development";public string ApplicationName {get;set;}="EffectTests";public string ContentRootPath {get;set;}="";public IFileProvider ContentRootFileProvider {get;set;}=new NullFileProvider();
}

class NoopJS : IJSRuntime {
 public ValueTask<TValue> InvokeAsync<TValue>(string identifier, object?[]? args)=>ValueTask.FromResult(default(TValue)!);
 public ValueTask<TValue> InvokeAsync<TValue>(string identifier, CancellationToken cancellationToken, object?[]? args)=>ValueTask.FromResult(default(TValue)!);
}
