namespace HistoricalAtlas.Domain;

public sealed class YearEntry { public int Year { get; set; } }
public sealed class Country { public int Id { get; set; } public string Name { get; set; } = ""; }
public sealed class Category
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public bool ShowTotal { get; set; }
}
public sealed class Equipment
{
    public int Id { get; set; }
    public int CategoryId { get; set; }
    public string Name { get; set; } = "";
    // GroupName is retained for compatibility with legacy scenarios; CategoryId is authoritative.
    public string GroupName { get; set; } = "";
    public string Unit { get; set; } = "units";
}
/// <summary>A scenario-wide resource definition. Income and usage have independent units/year.</summary>
public sealed class ResourceType
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string Unit { get; set; } = "units";
    public string IncomeLabel { get; set; } = "Annual production";
    public string UsageLabel { get; set; } = "Annual usage";
}
public sealed class ResourcePlan
{
    public int CountryId { get; set; }
    public int ResourceId { get; set; }
    public int StartYear { get; set; }
    public decimal StartingStock { get; set; }
    public decimal AnnualIncome { get; set; }
    public decimal AnnualUsage { get; set; } // Positive outflow; net = income - usage.
}
public sealed class ResourceOverride
{
    public int CountryId { get; set; }
    public int ResourceId { get; set; }
    public int Year { get; set; }
    public decimal Amount { get; set; }
}
public sealed class ResourceResult
{
    public bool Configured { get; set; }
    public int Year { get; set; }
    public decimal Stock { get; set; }
    public decimal DefaultStock { get; set; }
    public decimal Income { get; set; }
    public decimal Usage { get; set; }
    public bool IsOverridden { get; set; }
    public decimal RawAnnual { get; set; }
    public decimal Stage1Percent { get; set; }
    public decimal Stage1Linked { get; set; }
    public decimal AfterStage1 { get; set; }
    public decimal Stage2Percent { get; set; }
    public decimal Stage2Linked { get; set; }
    public decimal AfterStage2 { get; set; }
    public decimal InventoryStage1Percent { get; set; }
    public decimal InventoryStage2Percent { get; set; }
    public decimal InventoryStage1Linked { get; set; }
    public decimal InventoryStage2Linked { get; set; }
    public List<GlobalEffect> AppliedGlobalEffects { get; set; } = new();
    public decimal NetChange => Income - Usage;
}
public sealed class StockPlan
{
    public int CountryId { get; set; }
    public int EquipmentId { get; set; }
    public int StartYear { get; set; }
    public decimal StartingStock { get; set; }
    public decimal AnnualRaw { get; set; }
}
public sealed class IndividualEffect
{
    public int Id { get; set; }
    public int CountryId { get; set; }
    public int EquipmentId { get; set; }
    public string Name { get; set; } = "";
    public int Stage { get; set; } = 1;
    public string Kind { get; set; } = "Percent";
    public decimal Value { get; set; }
    public int? FromYear { get; set; }
    public int? ToYear { get; set; }
}
public sealed class GlobalEffectSource
{
    public int CountryId { get; set; } // 0 = default selection for every country
    public int EquipmentId { get; set; }
}
public sealed class GlobalEffect
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public int Stage { get; set; } = 1;
    // Existing effects default to equipment; newer ones can target resources.
    public string TargetDomain { get; set; } = "Equipment";
    public string TargetKind { get; set; } = "Annual";
    public decimal Percent { get; set; }
    public string Description { get; set; } = "";
    public string ValueMode { get; set; } = "Percent"; // Percent, Fixed, CategoryStock, EquipmentAnnual or EquipmentRate; Percent stores the signed value for each mode.
    public List<GlobalEffectSource> SourceCategories { get; set; } = new();
    public int? FromYear { get; set; }
    public int? ToYear { get; set; }
    public List<int> EquipmentIds { get; set; } = new();
    public List<int> ResourceIds { get; set; } = new();
    public List<int> CountryIds { get; set; } = new(); // Empty means all countries.
}
public sealed class StockOverride
{
    public int CountryId { get; set; }
    public int EquipmentId { get; set; }
    public int Year { get; set; }
    public decimal Amount { get; set; }
}
public sealed class MapLayer
{
    public int Id { get; set; }
    public int Year { get; set; }
    public string Type { get; set; } = "Base";
    public string FileName { get; set; } = "";
    public decimal OffsetX { get; set; }
    public decimal OffsetY { get; set; }
    public decimal Scale { get; set; } = 1;
    public decimal Opacity { get; set; } = 1;
}
public sealed class Account
{
    public int Id { get; set; }
    public string Username { get; set; } = "";
    public string Role { get; set; } = "User";
}
public sealed class AtlasSnapshot
{
    public List<int> Years { get; set; } = new();
    public List<int> PrivateYears { get; set; } = new();
    public List<Country> Countries { get; set; } = new();
    public List<Category> Categories { get; set; } = new();
    public List<Equipment> Equipment { get; set; } = new();
    public List<StockPlan> Plans { get; set; } = new();
    public List<ResourceType> Resources { get; set; } = new();
    public List<ResourcePlan> ResourcePlans { get; set; } = new();
    public List<ResourceOverride> ResourceOverrides { get; set; } = new();
    public List<IndividualEffect> IndividualEffects { get; set; } = new();
    public List<GlobalEffect> GlobalEffects { get; set; } = new();
    public List<StockOverride> Overrides { get; set; } = new();
    public List<MapLayer> Layers { get; set; } = new();
    public string MapTitle { get; set; } = "MUN Crisis Hub";
    public string Coverage { get; set; } = "Administrator-defined geography";
}
public readonly record struct InventoryYearChanges(decimal? Current, decimal? Expected);

public sealed class InventoryResult
{
    public int Year { get; set; }
    public decimal Stock { get; set; }
    public decimal DefaultStock { get; set; }
    public bool IsOverridden { get; set; }
    public decimal RawAnnual { get; set; }
    public decimal Stage1Fixed { get; set; }
    public decimal Stage1Percent { get; set; }
    public decimal Stage1Linked { get; set; }
    public decimal AfterStage1 { get; set; }
    public decimal Stage2Percent { get; set; }
    public decimal Stage2Linked { get; set; }
    public decimal AfterStage2 { get; set; }
    public decimal FinalAnnualChange { get; set; }
    public decimal InventoryStage1Percent { get; set; }
    public decimal InventoryStage2Percent { get; set; }
    public decimal InventoryStage1Linked { get; set; }
    public decimal InventoryStage2Linked { get; set; }
    public List<IndividualEffect> AppliedIndividualEffects { get; set; } = new();
    public List<GlobalEffect> AppliedGlobalEffects { get; set; } = new();
}
