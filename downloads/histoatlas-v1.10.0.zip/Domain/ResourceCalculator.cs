namespace HistoricalAtlas.Domain;

/// <summary>
/// Resources use the same two sequential stages as logistics.
/// Stage 1: (income - usage) * (1 + combined percentage) + fixed amounts + linked amounts.
/// Stage 2: stage1 * (1 + combined percentage) + fixed amounts + linked amounts.
/// Stock-directed effects apply after the annual delta in stage order.
/// Equipment-linked consumption uses POSITIVE net annual equipment change only,
/// so losing equipment never creates free raw materials. Cross-unit coefficient
/// (% of equipment count expressed in the destination resource's unit) is an
/// explicitly modeled conversion rule, NOT literal material composition.
/// </summary>
public static class ResourceCalculator
{
    public static bool Applies(GlobalEffect effect, int countryId, int resourceId, int year) =>
        effect.TargetDomain == "Resource" && effect.ResourceIds.Contains(resourceId) &&
        (effect.CountryIds.Count == 0 || effect.CountryIds.Contains(countryId)) &&
        AtlasCalculator.Active(effect.FromYear, effect.ToYear, year);

    // Rate mode expresses resource units (tonnes, barrels, dollars) per positive added equipment item.
    public static decimal LinkedEquipmentRate(GlobalEffect effect, int countryId, IReadOnlyDictionary<int, decimal> deltas)
    {
        var sources = effect.SourceCategories.Where(x => x.CountryId == countryId).Select(x => x.EquipmentId).Distinct().ToList();
        if (sources.Count == 0) sources = effect.SourceCategories.Where(x => x.CountryId == 0).Select(x => x.EquipmentId).Distinct().ToList();
        return sources.Sum(id => deltas.GetValueOrDefault(id)) * effect.Percent;
    }

    public static ResourceResult Calculate(AtlasSnapshot snapshot, int countryId, int resourceId, int year)
    {
        var plan = snapshot.ResourcePlans.FirstOrDefault(p => p.CountryId == countryId && p.ResourceId == resourceId);
        if (plan is null || year < plan.StartYear) return new ResourceResult { Year = year };
        var overrides = snapshot.ResourceOverrides.Where(o => o.CountryId == countryId && o.ResourceId == resourceId)
            .ToDictionary(o => o.Year, o => o.Amount);
        decimal stock = plan.StartingStock;
        ResourceResult result = new() { Year = year };
        for (int cursor = plan.StartYear; cursor <= year; cursor++)
        {
            bool initial = cursor == plan.StartYear;
            var globals = initial ? new List<GlobalEffect>() : snapshot.GlobalEffects
                .Where(g => Applies(g, countryId, resourceId, cursor)).ToList();
            decimal raw = initial ? 0m : plan.AnnualIncome - plan.AnnualUsage;
            decimal p1 = globals.Where(g => g.Stage == 1 && g.TargetKind == "Annual" && g.ValueMode == "Percent").Sum(g => g.Percent);
            decimal p2 = globals.Where(g => g.Stage == 2 && g.TargetKind == "Annual" && g.ValueMode == "Percent").Sum(g => g.Percent);
            // Evaluate the equipment source deltas just once per annual transition,
            // never recursively through resource calculations.
            Dictionary<int, decimal>? equipmentDeltas = null;
            Dictionary<int, decimal>? equipmentPriorStocks = null;
            decimal Linked(GlobalEffect g)
            {
                if (g.ValueMode == "Fixed") return g.Percent;
                if (g.ValueMode is "EquipmentAnnual" or "EquipmentRate")
                {
                    if (equipmentDeltas is null)
                    {
                        var current = AtlasCalculator.CalculateCountry(snapshot, countryId, cursor);
                        var previous = AtlasCalculator.CalculateCountry(snapshot, countryId, cursor - 1);
                        equipmentDeltas = current.Where(x => snapshot.Plans.Any(p => p.CountryId == countryId &&
                            p.EquipmentId == x.Key && p.StartYear < cursor))
                            .ToDictionary(x => x.Key,
                            x => Math.Max(0m, x.Value.Stock - (previous.GetValueOrDefault(x.Key)?.Stock ?? 0m)));
                    }
                    return g.ValueMode == "EquipmentRate"
                        ? LinkedEquipmentRate(g, countryId, equipmentDeltas) : AtlasCalculator.LinkedAmount(g, countryId, equipmentDeltas);
                }
                if (g.ValueMode == "CategoryStock")
                {
                    equipmentPriorStocks ??= AtlasCalculator.CalculateCountry(snapshot, countryId, cursor-1)
                        .ToDictionary(x => x.Key, x => x.Value.Stock);
                    return AtlasCalculator.LinkedAmount(g, countryId, equipmentPriorStocks);
                }
                return 0m;
            }
            decimal linked1 = globals.Where(g => g.Stage == 1 && g.TargetKind == "Annual" && g.ValueMode != "Percent").Sum(Linked);
            decimal after1 = raw * (1m + p1 / 100m) + linked1;
            decimal linked2 = globals.Where(g => g.Stage == 2 && g.TargetKind == "Annual" && g.ValueMode != "Percent").Sum(Linked);
            decimal after2 = after1 * (1m + p2 / 100m) + linked2;
            decimal delta = initial ? 0m : Math.Round(after2, 2, MidpointRounding.AwayFromZero);
            decimal sp1 = globals.Where(g => g.Stage == 1 && g.TargetKind == "Stock" && g.ValueMode == "Percent").Sum(g => g.Percent);
            decimal sp2 = globals.Where(g => g.Stage == 2 && g.TargetKind == "Stock" && g.ValueMode == "Percent").Sum(g => g.Percent);
            decimal sl1 = globals.Where(g => g.Stage == 1 && g.TargetKind == "Stock" && g.ValueMode != "Percent").Sum(Linked);
            decimal sl2 = globals.Where(g => g.Stage == 2 && g.TargetKind == "Stock" && g.ValueMode != "Percent").Sum(Linked);
            decimal projected = Math.Round(((stock + delta) * (1m + sp1 / 100m) + sl1) * (1m + sp2 / 100m) + sl2,
                2, MidpointRounding.AwayFromZero);
            bool overridden = overrides.TryGetValue(cursor, out var replacement);
            stock = overridden ? replacement : projected;
            result = new ResourceResult
            {
                Configured = true, Year = cursor, Stock = stock, DefaultStock = projected,
                Income = initial ? 0m : plan.AnnualIncome, Usage = initial ? 0m : plan.AnnualUsage,
                IsOverridden = overridden, RawAnnual = raw, Stage1Percent = p1, Stage1Linked = linked1,
                AfterStage1 = after1, Stage2Percent = p2, Stage2Linked = linked2,
                AfterStage2 = after2, InventoryStage1Percent = sp1, InventoryStage2Percent = sp2,
                InventoryStage1Linked = sl1, InventoryStage2Linked = sl2, AppliedGlobalEffects = globals
            };
        }
        return result;
    }
}
