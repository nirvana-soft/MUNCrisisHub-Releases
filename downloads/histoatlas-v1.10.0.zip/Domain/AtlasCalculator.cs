namespace HistoricalAtlas.Domain;

/// <summary>
/// Annual simulator, in chronological order across ALL categories for a country.
/// Category-linked modifiers read the selected SOURCE categories' closing inventory
/// from the PREVIOUS calendar year, avoiding same-year circular dependencies.
/// Stage 1: (raw + fixed) * (1 + combined percentage) + fixed global amounts + source-linked amounts.
/// Stage 2: stage1 * (1 + combined percentage) + fixed global amounts + source-linked amounts.
/// Stock-wide percentage and source-linked modifiers then apply in stage order.
/// Each stage is rounded only when the annual delta or closing stock is committed.
/// Baseline inventories may be explicitly overridden and stocks may be negative.
/// </summary>
public static class AtlasCalculator
{
    public static bool Active(int? from, int? to, int year) =>
        (!from.HasValue || year >= from.Value) && (!to.HasValue || year <= to.Value);

    public static decimal Whole(decimal n) => Math.Round(n, 0, MidpointRounding.AwayFromZero);

    public static bool Applies(GlobalEffect effect, int countryId, int categoryId, int year) =>
        effect.TargetDomain == "Equipment" && effect.EquipmentIds.Contains(categoryId) &&
        (effect.CountryIds.Count == 0 || effect.CountryIds.Contains(countryId)) &&
        Active(effect.FromYear, effect.ToYear, year);

    public static decimal LinkedAmount(GlobalEffect effect, int countryId, IReadOnlyDictionary<int, decimal> priorStocks)
    {
        // Country-specific sources supersede the default (country ID zero) source list.
        var sources = effect.SourceCategories.Where(x => x.CountryId == countryId).Select(x => x.EquipmentId).Distinct().ToList();
        if (sources.Count == 0)
            sources = effect.SourceCategories.Where(x => x.CountryId == 0).Select(x => x.EquipmentId).Distinct().ToList();
        return sources.Sum(x => priorStocks.GetValueOrDefault(x)) * effect.Percent / 100m;
    }

    public static Dictionary<int, InventoryResult> CalculateCountry(AtlasSnapshot data, int countryId, int requestedYear)
    {
        var plans = data.Plans.Where(p => p.CountryId == countryId).ToDictionary(p => p.EquipmentId);
        var results = new Dictionary<int, InventoryResult>();
        if (plans.Count == 0) return results;
        int firstYear = plans.Values.Min(p => p.StartYear);
        if (requestedYear < firstYear) return results;

        var previous = new Dictionary<int, decimal>();
        for (int year = firstYear; year <= requestedYear; year++)
        {
            var current = new Dictionary<int, InventoryResult>();
            foreach (var (categoryId, plan) in plans)
            {
                if (year < plan.StartYear) continue;
                var individuals = data.IndividualEffects
                    .Where(e => e.CountryId == countryId && e.EquipmentId == categoryId && Active(e.FromYear, e.ToYear, year)).ToList();
                var globals = data.GlobalEffects.Where(g => Applies(g, countryId, categoryId, year)).ToList();
                var stockOverride = data.Overrides.FirstOrDefault(o => o.CountryId == countryId && o.EquipmentId == categoryId && o.Year == year);
                bool initial = year == plan.StartYear;
                decimal raw = initial ? 0 : plan.AnnualRaw;
                decimal fixed1 = initial ? 0 : individuals.Where(e => e.Stage == 1 && e.Kind == "Fixed").Sum(e => e.Value);
                decimal percent1 = initial ? 0 : individuals.Where(e => e.Stage == 1 && e.Kind == "Percent").Sum(e => e.Value)
                     + globals.Where(g => g.Stage == 1 && g.TargetKind == "Annual" && g.ValueMode == "Percent").Sum(g => g.Percent);
                decimal linked1 = initial ? 0 : globals.Where(g => g.Stage == 1 && g.TargetKind == "Annual" && g.ValueMode is "CategoryStock" or "Fixed")
                    .Sum(g => g.ValueMode == "Fixed" ? g.Percent : LinkedAmount(g, countryId, previous));
                decimal stage1 = (raw + fixed1) * (1m + percent1 / 100m) + linked1;
                decimal percent2 = initial ? 0 : individuals.Where(e => e.Stage == 2 && e.Kind == "Percent").Sum(e => e.Value)
                    + globals.Where(g => g.Stage == 2 && g.TargetKind == "Annual" && g.ValueMode == "Percent").Sum(g => g.Percent);
                decimal linked2 = initial ? 0 : globals.Where(g => g.Stage == 2 && g.TargetKind == "Annual" && g.ValueMode is "CategoryStock" or "Fixed")
                    .Sum(g => g.ValueMode == "Fixed" ? g.Percent : LinkedAmount(g, countryId, previous));
                decimal stage2 = stage1 * (1m + percent2 / 100m) + linked2;
                decimal delta = initial ? 0 : Whole(stage2);

                // Stock effects are separate from annual production/usage modifiers.
                decimal stockPct1 = initial ? 0 : globals.Where(g => g.Stage == 1 && g.TargetKind == "Stock" && g.ValueMode == "Percent").Sum(g => g.Percent);
                decimal stockPct2 = initial ? 0 : globals.Where(g => g.Stage == 2 && g.TargetKind == "Stock" && g.ValueMode == "Percent").Sum(g => g.Percent);
                decimal stockLinked1 = initial ? 0 : globals.Where(g => g.Stage == 1 && g.TargetKind == "Stock" && g.ValueMode is "CategoryStock" or "Fixed")
                    .Sum(g => g.ValueMode == "Fixed" ? g.Percent : LinkedAmount(g, countryId, previous));
                decimal stockLinked2 = initial ? 0 : globals.Where(g => g.Stage == 2 && g.TargetKind == "Stock" && g.ValueMode is "CategoryStock" or "Fixed")
                    .Sum(g => g.ValueMode == "Fixed" ? g.Percent : LinkedAmount(g, countryId, previous));
                decimal beforeStock = initial ? plan.StartingStock : previous.GetValueOrDefault(categoryId) + delta;
                decimal projected = Whole((beforeStock * (1m + stockPct1 / 100m) + stockLinked1) * (1m + stockPct2 / 100m) + stockLinked2);
                decimal final = stockOverride is null ? projected : Whole(stockOverride.Amount);
                current[categoryId] = new InventoryResult
                {
                    Year = year, Stock = final, DefaultStock = projected, IsOverridden = stockOverride is not null,
                    RawAnnual = raw, Stage1Fixed = fixed1, Stage1Percent = percent1, Stage1Linked = linked1,
                    AfterStage1 = stage1, Stage2Percent = percent2, Stage2Linked = linked2,
                    AfterStage2 = stage2, FinalAnnualChange = delta,
                    InventoryStage1Percent = stockPct1, InventoryStage2Percent = stockPct2,
                    InventoryStage1Linked = stockLinked1, InventoryStage2Linked = stockLinked2,
                    AppliedIndividualEffects = individuals, AppliedGlobalEffects = globals
                };
            }
            previous = current.ToDictionary(x => x.Key, x => x.Value.Stock);
            results = current;
        }
        return results;
    }

    public static InventoryResult Calculate(AtlasSnapshot data, int countryId, int categoryId, int year)
        => CalculateCountry(data, countryId, year).GetValueOrDefault(categoryId) ?? new InventoryResult { Year = year };

    public static InventoryYearChanges GetYearChanges(AtlasSnapshot data, int countryId, int categoryId, int year)
    {
        var plan = data.Plans.FirstOrDefault(x => x.CountryId == countryId && x.EquipmentId == categoryId);
        if (plan is null || year < plan.StartYear) return new(null, null);
        var current = Calculate(data, countryId, categoryId, year).Stock;
        decimal? actual = year > plan.StartYear ? current - Calculate(data, countryId, categoryId, year - 1).Stock : null;
        decimal expected = Calculate(data, countryId, categoryId, year + 1).Stock - current;
        return new(actual, expected);
    }
}
