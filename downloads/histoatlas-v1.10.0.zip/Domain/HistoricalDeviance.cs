namespace HistoricalAtlas.Domain;

/// <summary>
/// Audits the difference between the selected registered year and the previous
/// registered year. Every intermediate calendar year is simulated, even when it
/// cannot be selected on the slider. The four components reconcile exactly to
/// the actual closing-stock change, including stock effects and overrides.
/// </summary>
public static class HistoricalDevianceCalculator
{
    public static HistoricalDeviance? Calculate(AtlasSnapshot data, int countryId, int equipmentId, int selectedYear, IEnumerable<int>? permittedYears = null)
    {
        var previousDate = (permittedYears ?? data.Years).Where(y => y < selectedYear).OrderByDescending(y => y).FirstOrDefault();
        if (previousDate == 0) return null;

        var plan = data.Plans.FirstOrDefault(x => x.CountryId == countryId && x.EquipmentId == equipmentId);
        if (plan is null || plan.StartYear > previousDate) return null;

        var openingYear = AtlasCalculator.CalculateCountry(data, countryId, previousDate);
        if (!openingYear.TryGetValue(equipmentId, out var opening)) return null;

        decimal priorStock = opening.Stock;
        decimal raw = 0m, production = 0m, usage = 0m, inventory = 0m;
        var applied = new Dictionary<string, HistoricalAppliedEffect>();

        for (int year = previousDate + 1; year <= selectedYear; year++)
        {
            var before = AtlasCalculator.CalculateCountry(data, countryId, year - 1);
            var after = AtlasCalculator.CalculateCountry(data, countryId, year);
            if (!after.TryGetValue(equipmentId, out var entry)) continue;
            var sourceStocks = before.ToDictionary(x => x.Key, x => x.Value.Stock);

            // The engine commits only rounded annual deltas. Keep the historical
            // accounting in committed whole units, with no rounding discrepancy.
            var productionOutput = AtlasCalculator.Whole(entry.AfterStage1);
            raw += entry.RawAnnual;
            production += productionOutput - entry.RawAnnual;
            usage += entry.FinalAnnualChange - productionOutput;
            inventory += entry.Stock - (priorStock + entry.FinalAnnualChange);

            foreach (var individual in entry.AppliedIndividualEffects)
            {
                if (year == plan.StartYear) continue;
                Add("I:" + individual.Id, individual.Name, individual.Stage,
                    "Annual", individual.Kind, individual.Value, year, false, 0);
            }
            foreach (var global in entry.AppliedGlobalEffects)
            {
                if (year == plan.StartYear) continue;
                var linked = global.ValueMode == "CategoryStock";
                var linkedAmount = linked ? AtlasCalculator.LinkedAmount(global, countryId, sourceStocks) : 0m;
                Add("G:" + global.Id, global.Name, global.Stage, global.TargetKind,
                    linked ? "Linked" : global.ValueMode, global.Percent, year, linked, linkedAmount);
            }
            if (entry.IsOverridden)
            {
                Add("O:" + year, "Manual stock override", 0, "Stock", "Override",
                    entry.Stock - entry.DefaultStock, year, false, 0);
            }
            priorStock = entry.Stock;
        }
        var result = new HistoricalDeviance
        {
            FromYear = previousDate, ToYear = selectedYear,
            OpeningStock = opening.Stock, ClosingStock = priorStock,
            Raw = raw, ProductionAdjustment = production, UsageAdjustment = usage,
            InventoryAdjustment = inventory,
            AppliedEffects = applied.Values
                .OrderByDescending(e => e.LatestYear)
                .ThenByDescending(e => Math.Abs(e.LinkedImpact))
                .ThenBy(e => e.Name)
                .ToList()
        };
        return result;

        void Add(string key, string name, int stage, string scope, string kind,
            decimal issued, int year, bool linked, decimal actualLinkedAmount)
        {
            if (!applied.TryGetValue(key, out var item))
            {
                item = new HistoricalAppliedEffect
                {
                    Name = name, Stage = stage, Scope = scope, Kind = kind,
                    IssuedValue = issued, EarliestYear = year, LatestYear = year,
                    IsLinked = linked
                };
                applied.Add(key, item);
            }
            item.LatestYear = year;
            item.Count++;
            item.LinkedImpact += actualLinkedAmount;
        }
    }
}

public sealed class HistoricalDeviance
{
    public int FromYear { get; init; }
    public int ToYear { get; init; }
    public decimal OpeningStock { get; init; }
    public decimal ClosingStock { get; init; }
    public decimal Raw { get; init; }
    public decimal ProductionAdjustment { get; init; }
    public decimal UsageAdjustment { get; init; }
    public decimal InventoryAdjustment { get; init; }
    public decimal NetChange => ClosingStock - OpeningStock;
    public List<HistoricalAppliedEffect> AppliedEffects { get; init; } = new();
}

public sealed class HistoricalAppliedEffect
{
    public string Name { get; init; } = "";
    public int Stage { get; init; }
    public string Scope { get; init; } = "";
    public string Kind { get; init; } = "";
    public decimal IssuedValue { get; init; }
    public int EarliestYear { get; init; }
    public int LatestYear { get; set; }
    public int Count { get; set; }
    public bool IsLinked { get; init; }
    public decimal LinkedImpact { get; set; }
}
