namespace HistoricalAtlas.Domain;

/// <summary>Human-readable effect target scopes, shared by management and public reporting.</summary>
public static class GlobalEffectScope
{
    public static string Describe(GlobalEffect effect, AtlasSnapshot snapshot)
    {
        if (effect.TargetDomain == "Resource")
        {
            var chosen = snapshot.Resources.Where(r => effect.ResourceIds.Contains(r.Id)).ToList();
            if (chosen.Count == 0) return "No resources";
            if (chosen.Count == snapshot.Resources.Count) return "All Resources";
            return string.Join(", ", chosen.Select(r => r.Name));
        }

        var selected = snapshot.Equipment.Where(e => effect.EquipmentIds.Contains(e.Id)).ToList();
        if (selected.Count == 0) return "No logistics sub-types";
        if (selected.Count == snapshot.Equipment.Count)
            return "All Categories (All Logistics)";

        var groups = new List<string>();
        foreach (var category in snapshot.Categories)
        {
            var allInCategory = snapshot.Equipment.Where(e => e.CategoryId == category.Id).ToList();
            if (allInCategory.Count == 0) continue;
            var chosen = allInCategory.Where(e => effect.EquipmentIds.Contains(e.Id)).ToList();
            if (chosen.Count == 0) continue;
            if (chosen.Count == allInCategory.Count)
                groups.Add("All " + CategoryDisplayName(category.Name));
            else
                groups.Add(category.Name + ": " + string.Join(", ", chosen.Select(e => e.Name)));
        }
        // Old scenario saves can contain equipment without a matching category.
        var orphaned = selected.Where(e => !snapshot.Categories.Any(c => c.Id == e.CategoryId));
        groups.AddRange(orphaned.Select(e => e.Name));
        return string.Join(" · ", groups);
    }

    private static string CategoryDisplayName(string name)
    {
        // Match conventional labels in the HistoAtlas default category set.
        return name.Equals("Available Equipment", StringComparison.OrdinalIgnoreCase) ||
               name.Equals("Equipment", StringComparison.OrdinalIgnoreCase) ||
               name.Equals("Equipments", StringComparison.OrdinalIgnoreCase)
            ? "Equipments" : name;
    }
}
