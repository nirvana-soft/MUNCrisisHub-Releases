namespace HistoricalAtlas.Services;
public sealed class TimelineState
{
    public int? Year { get; private set; }
    public event Action? Changed;
    public void Clear()
    {
        if (Year is null) return;
        Year=null;
        Changed?.Invoke();
    }
    public void Select(int year)
    {
        if (Year == year) return;
        Year = year;
        Changed?.Invoke();
    }
}
