using HistoricalAtlas.Domain;
using Microsoft.Data.Sqlite;


namespace HistoricalAtlas.Services;

/// <summary>Local SQLite repository. Per-operation connections and a write lock make it safe for concurrent Blazor circuits.</summary>
public sealed class AtlasStore : IDisposable
{
    private readonly object gate = new();
    private readonly string dbPath;
    private readonly AccountStore accounts;
    private readonly ScenarioCatalog catalog;
    public string Slug { get; }
    public string UploadDirectory { get; }
    public string DatabasePath => dbPath;
    public event Action? Updated;
    public long Version { get; private set; }

    public AtlasStore(ScenarioCatalog catalog, AccountStore accounts, string slug)
    {
        this.catalog = catalog;
        this.accounts = accounts;
        var scenario = catalog.Get(slug) ?? throw new InvalidOperationException("Scenario not found.");
        Slug = scenario.Slug;
        var dir = catalog.ScenarioDirectory(Slug);
        Directory.CreateDirectory(dir);
        UploadDirectory = Path.Combine(dir, "uploads");
        Directory.CreateDirectory(UploadDirectory);
        dbPath = Path.Combine(dir, "scenario.sqlite");
        catalog.DataUpdated += OnScenarioUpdated;
    }
    private void OnScenarioUpdated(string slug)
    {
        if (slug != Slug) return;
        Version++;
        Updated?.Invoke();
    }
    private SqliteConnection Open()
    {
        var conn = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = dbPath, Mode = SqliteOpenMode.ReadWriteCreate }.ToString());
        conn.Open();
        using var pragma = conn.CreateCommand();
        pragma.CommandText = "PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;";
        pragma.ExecuteNonQuery();
        return conn;
    }
    // Microsoft.Data.Sqlite does not expose SqliteConnection.Transaction publicly.
    // Commands that participate in a transaction must receive it explicitly.
    private static SqliteCommand Cmd(SqliteConnection con, string sql, params (string Key, object? Value)[] p)
        => Cmd(con, null, sql, p);

    private static SqliteCommand Cmd(SqliteConnection con, SqliteTransaction? transaction, string sql,
        params (string Key, object? Value)[] p)
    {
        var cmd = con.CreateCommand();
        cmd.CommandText = sql;
        if (transaction is not null) cmd.Transaction = transaction;
        foreach (var (key, val) in p) cmd.Parameters.AddWithValue(key, val ?? DBNull.Value);
        return cmd;
    }
    private static void Execute(SqliteConnection c, string sql, params (string, object?)[] p)
    { using var cmd = Cmd(c, sql, p); cmd.ExecuteNonQuery(); }
    private static void Execute(SqliteConnection c, SqliteTransaction tx, string sql, params (string, object?)[] p)
    { using var cmd = Cmd(c, tx, sql, p); cmd.ExecuteNonQuery(); }
    private static object? Scalar(SqliteConnection c, string sql, params (string, object?)[] p)
    { using var cmd = Cmd(c, sql, p); return cmd.ExecuteScalar(); }
    private static object? Scalar(SqliteConnection c, SqliteTransaction tx, string sql, params (string, object?)[] p)
    { using var cmd = Cmd(c, tx, sql, p); return cmd.ExecuteScalar(); }
    private static List<T> Query<T>(SqliteConnection c, string sql, Func<SqliteDataReader, T> map)
    {
        using var cmd = Cmd(c, sql); using var r = cmd.ExecuteReader(); var items = new List<T>();
        while (r.Read()) items.Add(map(r));
        return items;
    }
    private static int? OptInt(SqliteDataReader r, int i) => r.IsDBNull(i) ? null : r.GetInt32(i);
    private static decimal Dec(SqliteDataReader r, int i) => Convert.ToDecimal(r.GetValue(i), System.Globalization.CultureInfo.InvariantCulture);
    private void Raise() => catalog.NotifyDataUpdated(Slug);

    public void Initialize()
    {
        lock (gate)
        {
            using var c = Open();
            Execute(c, """
            CREATE TABLE IF NOT EXISTS Years (Year INTEGER PRIMARY KEY);
            CREATE TABLE IF NOT EXISTS Settings (Key TEXT PRIMARY KEY, Value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS Countries (Id INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT NOT NULL UNIQUE COLLATE NOCASE);
            CREATE TABLE IF NOT EXISTS Categories (Id INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT NOT NULL UNIQUE COLLATE NOCASE,
                ShowTotal INTEGER NOT NULL DEFAULT 0);
            CREATE TABLE IF NOT EXISTS Equipment (Id INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT NOT NULL UNIQUE COLLATE NOCASE,
                GroupName TEXT NOT NULL, Unit TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS Plans (CountryId INTEGER NOT NULL REFERENCES Countries(Id) ON DELETE CASCADE,
                EquipmentId INTEGER NOT NULL REFERENCES Equipment(Id) ON DELETE CASCADE,
                StartYear INTEGER NOT NULL, StartingStock REAL NOT NULL DEFAULT 0, AnnualRaw REAL NOT NULL DEFAULT 0,
                PRIMARY KEY (CountryId, EquipmentId));
            CREATE TABLE IF NOT EXISTS IndividualEffects (Id INTEGER PRIMARY KEY AUTOINCREMENT,
                CountryId INTEGER NOT NULL REFERENCES Countries(Id) ON DELETE CASCADE,
                EquipmentId INTEGER NOT NULL REFERENCES Equipment(Id) ON DELETE CASCADE,
                Name TEXT NOT NULL, Stage INTEGER NOT NULL, Kind TEXT NOT NULL, Value REAL NOT NULL,
                FromYear INTEGER, ToYear INTEGER);
            CREATE TABLE IF NOT EXISTS GlobalEffects (Id INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT NOT NULL,
                Stage INTEGER NOT NULL, TargetKind TEXT NOT NULL, Percent REAL NOT NULL, FromYear INTEGER, ToYear INTEGER, Description TEXT NOT NULL DEFAULT '', ValueMode TEXT NOT NULL DEFAULT 'Percent', TargetDomain TEXT NOT NULL DEFAULT 'Equipment');
            CREATE TABLE IF NOT EXISTS GlobalEffectSources (EffectId INTEGER NOT NULL REFERENCES GlobalEffects(Id) ON DELETE CASCADE,
                CountryId INTEGER NOT NULL DEFAULT 0,
                EquipmentId INTEGER NOT NULL REFERENCES Equipment(Id) ON DELETE CASCADE,
                PRIMARY KEY (EffectId, CountryId, EquipmentId));
            CREATE TABLE IF NOT EXISTS GlobalEffectTargets (EffectId INTEGER NOT NULL REFERENCES GlobalEffects(Id) ON DELETE CASCADE,
                EquipmentId INTEGER NOT NULL REFERENCES Equipment(Id) ON DELETE CASCADE,
                PRIMARY KEY (EffectId, EquipmentId));
            CREATE TABLE IF NOT EXISTS GlobalEffectResourceTargets (EffectId INTEGER NOT NULL REFERENCES GlobalEffects(Id) ON DELETE CASCADE,
                ResourceId INTEGER NOT NULL REFERENCES ResourceTypes(Id) ON DELETE CASCADE,
                PRIMARY KEY (EffectId, ResourceId));
            CREATE TABLE IF NOT EXISTS GlobalEffectCountryTargets (EffectId INTEGER NOT NULL REFERENCES GlobalEffects(Id) ON DELETE CASCADE,
                CountryId INTEGER NOT NULL REFERENCES Countries(Id) ON DELETE CASCADE,
                PRIMARY KEY (EffectId, CountryId));
            CREATE TABLE IF NOT EXISTS ResourceTypes (Id INTEGER PRIMARY KEY AUTOINCREMENT,
                Name TEXT NOT NULL UNIQUE COLLATE NOCASE, Unit TEXT NOT NULL,
                IncomeLabel TEXT NOT NULL, UsageLabel TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS ResourcePlans (CountryId INTEGER NOT NULL REFERENCES Countries(Id) ON DELETE CASCADE,
                ResourceId INTEGER NOT NULL REFERENCES ResourceTypes(Id) ON DELETE CASCADE,
                StartYear INTEGER NOT NULL REFERENCES Years(Year),
                StartingStock REAL NOT NULL DEFAULT 0, AnnualIncome REAL NOT NULL DEFAULT 0,
                AnnualUsage REAL NOT NULL DEFAULT 0,
                PRIMARY KEY (CountryId,ResourceId));
            CREATE TABLE IF NOT EXISTS ResourceOverrides (CountryId INTEGER NOT NULL REFERENCES Countries(Id) ON DELETE CASCADE,
                ResourceId INTEGER NOT NULL REFERENCES ResourceTypes(Id) ON DELETE CASCADE,
                Year INTEGER NOT NULL REFERENCES Years(Year) ON DELETE CASCADE, Amount REAL NOT NULL,
                PRIMARY KEY(CountryId,ResourceId,Year));
            CREATE TABLE IF NOT EXISTS StockOverrides (CountryId INTEGER NOT NULL REFERENCES Countries(Id) ON DELETE CASCADE,
                EquipmentId INTEGER NOT NULL REFERENCES Equipment(Id) ON DELETE CASCADE,
                Year INTEGER NOT NULL REFERENCES Years(Year) ON DELETE CASCADE, Amount REAL NOT NULL,
                PRIMARY KEY (CountryId, EquipmentId, Year));
            CREATE TABLE IF NOT EXISTS MapLayers (Id INTEGER PRIMARY KEY AUTOINCREMENT,
                Year INTEGER NOT NULL REFERENCES Years(Year) ON DELETE CASCADE,
                Type TEXT NOT NULL, FileName TEXT NOT NULL, OffsetX REAL NOT NULL DEFAULT 0,
                OffsetY REAL NOT NULL DEFAULT 0, Scale REAL NOT NULL DEFAULT 1, Opacity REAL NOT NULL DEFAULT 1,
                UNIQUE(Year, Type));
            """);
            // Migrate old flat equipment lists into a proper Category -> Sub-type hierarchy.
            // Existing sub-type IDs, plans, effects and stock overrides remain untouched.
            var equipmentColumns = Query(c, "PRAGMA table_info(Equipment)", r => r.GetString(1));
            if (!equipmentColumns.Contains("CategoryId"))
                Execute(c, "ALTER TABLE Equipment ADD COLUMN CategoryId INTEGER NOT NULL DEFAULT 0");
            var oldItems = Query(c, "SELECT Id,Name,GroupName,CategoryId FROM Equipment",
                r => (Id:r.GetInt32(0), Name:r.GetString(1), Group:r.GetString(2), CategoryId:r.GetInt32(3)));
            foreach (var old in oldItems.Where(x => x.CategoryId == 0))
            {
                // The preceding demo used the three top-level category names as items.
                // Preserve their IDs and their inventory records, but turn them into sub-types.
                bool formerCategory = old.Name is "Manpower" or "Deployed Troops" or "Available Equipment";
                var catName = formerCategory ? old.Name : old.Group switch
                {
                    "Equipment" or "Category" => "Available Equipment",
                    "Supplies" => "Supplies",
                    _ => string.IsNullOrWhiteSpace(old.Group) ? "Available Equipment" : old.Group
                };
                var show = catName is "Manpower" or "Deployed Troops" ? 1 : 0;
                Execute(c, "INSERT OR IGNORE INTO Categories(Name,ShowTotal) VALUES (@n,@t)", ("@n",catName),("@t",show));
                var catId = Convert.ToInt32(Scalar(c,"SELECT Id FROM Categories WHERE Name=@n",("@n",catName)));
                string newName = old.Name switch
                {
                    "Manpower" => "Available Manpower",
                    "Deployed Troops" => "Infantry Division",
                    "Available Equipment" => "Infantry Equipment",
                    _ => old.Name
                };
                Execute(c,"UPDATE Equipment SET CategoryId=@c,GroupName=@g,Name=@n WHERE Id=@id",
                    ("@c",catId),("@g",catName),("@n",newName),("@id",old.Id));
            }
            // Non-destructive migration for pre-existing scenario databases and imported archives.
            var columns = Query(c, "PRAGMA table_info(GlobalEffects)", r => r.GetString(1));
            if (!columns.Contains("Description")) Execute(c, "ALTER TABLE GlobalEffects ADD COLUMN Description TEXT NOT NULL DEFAULT ''");
            if (!columns.Contains("ValueMode")) Execute(c, "ALTER TABLE GlobalEffects ADD COLUMN ValueMode TEXT NOT NULL DEFAULT 'Percent'");
            if (!columns.Contains("TargetDomain")) Execute(c, "ALTER TABLE GlobalEffects ADD COLUMN TargetDomain TEXT NOT NULL DEFAULT 'Equipment'");
            var yearColumns = Query(c, "PRAGMA table_info(Years)", r => r.GetString(1));
            if (!yearColumns.Contains("IsPublic")) Execute(c, "ALTER TABLE Years ADD COLUMN IsPublic INTEGER NOT NULL DEFAULT 1");
            if (Convert.ToInt32(Scalar(c, "SELECT COUNT(*) FROM Years")) == 0)
                Execute(c, "INSERT INTO Years(Year) VALUES (1960)");
            Execute(c, "INSERT OR IGNORE INTO Settings(Key,Value) VALUES ('title','MUN Crisis Hub'),('coverage','Administrator-defined geography')");
            // Resource definitions are scenario-wide; existing military/logistics stocks are unaffected.
            // No plans are prepopulated: unconfigured country stocks must never masquerade as historical facts.
            if (Scalar(c, "SELECT Value FROM Settings WHERE Key='resource_defaults_initialized'") is null)
            {
                foreach (var (name,unit,income,usage) in new[] {
                ("Money", "$", "GDP / revenue", "Government spending / usage"),
                ("Oil", "barrels", "Annual extraction / imports", "Annual usage / exports"),
                ("Iron", "tonnes", "Annual production / imports", "Annual usage / exports"),
                ("Coal", "tonnes", "Annual production / imports", "Annual usage / exports"),
                ("Natural Gas", "m³", "Annual extraction / imports", "Annual usage / exports"),
                ("Food", "tonnes", "Annual production / imports", "Annual consumption / exports"),
                ("Copper", "tonnes", "Annual production / imports", "Annual usage / exports"),
                ("Tungsten", "tonnes", "Annual procurement / imports", "Annual industrial usage / exports"),
                ("Aluminum", "tonnes", "Annual production / imports", "Annual industrial usage / exports"),
                ("Rubber", "tonnes", "Annual production / imports", "Annual industrial usage / exports")
            })
                Execute(c, "INSERT OR IGNORE INTO ResourceTypes(Name,Unit,IncomeLabel,UsageLabel) VALUES (@n,@u,@i,@o)",
                    ("@n",name),("@u",unit),("@i",income),("@o",usage));
                Execute(c, "INSERT OR IGNORE INTO Settings(Key,Value) VALUES ('resource_defaults_initialized','1')");
            }
            // One-time, non-destructive resource migration for existing scenarios.
            // Do not repopulate deleted resource types after the marker is saved.
            if (Scalar(c, "SELECT Value FROM Settings WHERE Key='resource_types_v1_8_2_initialized'") is null)
            {
                foreach (var (name,unit,income,usage) in new[] {
                    ("Tungsten", "tonnes", "Annual procurement / imports", "Annual industrial usage / exports"),
                    ("Aluminum", "tonnes", "Annual production / imports", "Annual industrial usage / exports"),
                    ("Rubber", "tonnes", "Annual production / imports", "Annual industrial usage / exports")
                })
                    Execute(c, "INSERT OR IGNORE INTO ResourceTypes(Name,Unit,IncomeLabel,UsageLabel) VALUES (@n,@u,@i,@o)",
                        ("@n",name),("@u",unit),("@i",income),("@o",usage));
                Execute(c, "INSERT OR IGNORE INTO Settings(Key,Value) VALUES ('resource_types_v1_8_2_initialized','1')");
            }
        }
    }
    // User accounts are shared across scenarios and are never part of scenario archives.
    public Account? Authenticate(string username, string password) => accounts.Authenticate(username, password);
    public Account? Register(string username, string password) => accounts.Register(username, password);
    public Account? GetAccount(int id) => accounts.GetAccount(id);
    public List<Account> Accounts() => accounts.Accounts();
    public void SetRole(int id, string role) { accounts.SetRole(id, role); Raise(); }
    public void SetPassword(int id, string password) { accounts.SetPassword(id, password); Raise(); }
    public List<int> GetYears()
    {
        lock (gate) { using var c = Open(); return Query(c, "SELECT Year FROM Years ORDER BY Year", r => r.GetInt32(0)); }
    }
    public List<int> GetPublicYears()
    {
        lock (gate) { using var c=Open();return Query(c,"SELECT Year FROM Years WHERE IsPublic=1 ORDER BY Year",r=>r.GetInt32(0)); }
    }
    public bool IsYearPublic(int year)
    {
        lock(gate){using var c=Open();return Convert.ToInt32(Scalar(c,"SELECT COALESCE((SELECT IsPublic FROM Years WHERE Year=@y),0)",("@y",year)))==1;}
    }
    public bool IsPublicMapFile(string fileName)
    {
        lock(gate){using var c=Open();return Convert.ToInt32(Scalar(c,"SELECT COUNT(*) FROM MapLayers m JOIN Years y ON y.Year=m.Year WHERE m.FileName=@f AND y.IsPublic=1",("@f",fileName)))>0;}
    }
    /// <summary>
    /// A country-name image can be served to guests only if it is the effective
    /// country-name layer for a particular registered, public timeline year.
    /// An unregistered or private year cannot authorize an image request.
    /// This does not grant access to other private map-layer types.
    /// </summary>
    public bool IsCountryNamesVisibleInPublicYear(string fileName, int publicYear)
    {
        lock (gate)
        {
            using var c = Open();
            return Convert.ToInt32(Scalar(c, """
                SELECT COUNT(*) FROM MapLayers AS m
                WHERE m.Type='CountryNames' AND m.FileName=@file
                  AND m.Year = (
                      SELECT MAX(previous.Year) FROM MapLayers AS previous
                      WHERE previous.Type='CountryNames' AND previous.Year<=@year
                  )
                  AND EXISTS (SELECT 1 FROM Years AS y WHERE y.Year=@year AND y.IsPublic=1)
                """, ("@file", fileName), ("@year", publicYear))) > 0;
        }
    }
    public void SetYearPublic(int year, bool visible)
    {
        lock(gate){using var c=Open(); Execute(c,"UPDATE Years SET IsPublic=@p WHERE Year=@y",("@p",visible?1:0),("@y",year));}
        Raise();
    }
    /// <summary>
    /// Registers a year and creates independent layer records using the latest effective
    /// image of each type from an earlier year. The underlying image files are immutable:
    /// replacing a new year's image will not change any earlier year's layer.
    /// Returns the number of map layer templates created.
    /// </summary>
    public int AddYear(int year, bool isPublic = true)
    {
        if (year < 1 || year > 9999)
            throw new InvalidOperationException("Year must be between 1 and 9999.");

        int copiedLayers = 0;
        bool created;
        lock (gate)
        {
            using var c = Open();
            using var tx = c.BeginTransaction();
            using (var insertYear = Cmd(c, tx,
                "INSERT OR IGNORE INTO Years(Year,IsPublic) VALUES (@y,@p)",
                ("@y", year), ("@p", isPublic ? 1 : 0)))
            {
                created = insertYear.ExecuteNonQuery() > 0;
            }

            if (created)
            {
                // Each layer may last have been uploaded in a different earlier year.
                // Copy the layer currently in effect immediately before this year.
                // Only metadata is duplicated; sharing an immutable image filename is safe.
                using var copyMaps = Cmd(c, tx, """
                    INSERT OR IGNORE INTO MapLayers
                        (Year, Type, FileName, OffsetX, OffsetY, Scale, Opacity)
                    SELECT @year, previous.Type, previous.FileName,
                           previous.OffsetX, previous.OffsetY, previous.Scale, previous.Opacity
                    FROM MapLayers AS previous
                    WHERE previous.Year < @year
                      AND previous.Year = (
                          SELECT MAX(m.Year)
                          FROM MapLayers AS m
                          WHERE m.Type = previous.Type AND m.Year < @year
                      )
                    """, ("@year", year));
                copiedLayers = copyMaps.ExecuteNonQuery();
            }

            tx.Commit();
        }
        if (created) Raise();
        return copiedLayers;
    }
    public void DeleteYear(int year)
    {
        lock (gate)
        {
            using var c = Open();
            if (Convert.ToInt32(Scalar(c, "SELECT COUNT(*) FROM Years")) <= 1)
                throw new InvalidOperationException("At least one registered year is required.");
            if (Convert.ToInt32(Scalar(c, "SELECT COUNT(*) FROM Plans WHERE StartYear=@y", ("@y", year))) > 0)
                throw new InvalidOperationException("Move equipment baseline years before deleting this year.");
            if (Convert.ToInt32(Scalar(c, "SELECT COUNT(*) FROM ResourcePlans WHERE StartYear=@y", ("@y",year))) > 0)
                throw new InvalidOperationException("Move resource baseline years before deleting this year.");
            Execute(c, "DELETE FROM Years WHERE Year=@y", ("@y", year));
        }
        Raise();
    }
    public void SaveSettings(string title, string coverage)
    {
        if (string.IsNullOrWhiteSpace(title)) throw new InvalidOperationException("Enter a title.");
        lock (gate)
        {
            using var c = Open();
            Execute(c, "UPDATE Settings SET Value=@v WHERE Key='title'", ("@v", title.Trim()));
            Execute(c, "UPDATE Settings SET Value=@v WHERE Key='coverage'", ("@v", coverage.Trim()));
        }
        Raise();
    }
    public AtlasSnapshot Snapshot()
    {
        lock (gate)
        {
            using var c = Open();
            var data = new AtlasSnapshot();
            data.MapTitle = Scalar(c, "SELECT Value FROM Settings WHERE Key='title'")?.ToString() ?? "MUN Crisis Hub";
            data.Coverage = Scalar(c, "SELECT Value FROM Settings WHERE Key='coverage'")?.ToString() ?? "";
            data.Years = Query(c, "SELECT Year FROM Years ORDER BY Year", r => r.GetInt32(0));
            data.PrivateYears = Query(c, "SELECT Year FROM Years WHERE IsPublic=0 ORDER BY Year", r=>r.GetInt32(0));
            data.Countries = Query(c, "SELECT Id,Name FROM Countries ORDER BY Name", r => new Country { Id = r.GetInt32(0), Name = r.GetString(1) });
            data.Categories = Query(c,"SELECT Id,Name,ShowTotal FROM Categories ORDER BY Id",
                r => new Category { Id=r.GetInt32(0), Name=r.GetString(1), ShowTotal=r.GetInt32(2)!=0 });
            data.Equipment = Query(c, "SELECT Id,Name,GroupName,Unit,CategoryId FROM Equipment ORDER BY Name",
                r => new Equipment { Id = r.GetInt32(0), Name = r.GetString(1), GroupName = r.GetString(2), Unit = r.GetString(3), CategoryId=r.GetInt32(4) });
            data.Resources = Query(c, "SELECT Id,Name,Unit,IncomeLabel,UsageLabel FROM ResourceTypes ORDER BY Id",
                r => new ResourceType { Id = r.GetInt32(0), Name = r.GetString(1), Unit = r.GetString(2),
                    IncomeLabel = r.GetString(3), UsageLabel = r.GetString(4) });
            data.ResourcePlans = Query(c, "SELECT CountryId,ResourceId,StartYear,StartingStock,AnnualIncome,AnnualUsage FROM ResourcePlans",
                r => new ResourcePlan { CountryId = r.GetInt32(0), ResourceId = r.GetInt32(1), StartYear = r.GetInt32(2),
                    StartingStock = Dec(r, 3), AnnualIncome = Dec(r, 4), AnnualUsage = Dec(r, 5) });
            data.ResourceOverrides = Query(c, "SELECT CountryId,ResourceId,Year,Amount FROM ResourceOverrides",
                r => new ResourceOverride { CountryId = r.GetInt32(0), ResourceId = r.GetInt32(1), Year = r.GetInt32(2), Amount = Dec(r, 3) });
            data.Plans = Query(c, "SELECT CountryId,EquipmentId,StartYear,StartingStock,AnnualRaw FROM Plans",
                r => new StockPlan { CountryId = r.GetInt32(0), EquipmentId = r.GetInt32(1), StartYear = r.GetInt32(2), StartingStock = Dec(r, 3), AnnualRaw = Dec(r, 4) });
            data.IndividualEffects = Query(c, "SELECT Id,CountryId,EquipmentId,Name,Stage,Kind,Value,FromYear,ToYear FROM IndividualEffects ORDER BY Id",
                r => new IndividualEffect { Id = r.GetInt32(0), CountryId = r.GetInt32(1), EquipmentId = r.GetInt32(2), Name = r.GetString(3),
                    Stage = r.GetInt32(4), Kind = r.GetString(5), Value = Dec(r, 6), FromYear = OptInt(r, 7), ToYear = OptInt(r, 8) });
            data.GlobalEffects = Query(c, "SELECT Id,Name,Stage,TargetKind,Percent,FromYear,ToYear,Description,ValueMode,TargetDomain FROM GlobalEffects ORDER BY Id",
                r => new GlobalEffect { Id = r.GetInt32(0), Name = r.GetString(1), Stage = r.GetInt32(2), TargetKind = r.GetString(3),
                    Percent = Dec(r, 4), FromYear = OptInt(r, 5), ToYear = OptInt(r, 6),
                    Description = r.GetString(7), ValueMode = r.GetString(8), TargetDomain = r.GetString(9) });
            var targets = Query(c, "SELECT EffectId,EquipmentId FROM GlobalEffectTargets", r => (EffectId: r.GetInt32(0), EquipmentId: r.GetInt32(1)));
            foreach (var effect in data.GlobalEffects) effect.EquipmentIds = targets.Where(t => t.EffectId == effect.Id).Select(t => t.EquipmentId).ToList();
            var resourceTargets = Query(c, "SELECT EffectId,ResourceId FROM GlobalEffectResourceTargets", r => (EffectId:r.GetInt32(0), ResourceId:r.GetInt32(1)));
            foreach (var effect in data.GlobalEffects) effect.ResourceIds = resourceTargets.Where(r=>r.EffectId==effect.Id).Select(r=>r.ResourceId).ToList();
            var countryTargets = Query(c, "SELECT EffectId,CountryId FROM GlobalEffectCountryTargets", r => (EffectId: r.GetInt32(0), CountryId: r.GetInt32(1)));
            foreach (var effect in data.GlobalEffects) effect.CountryIds = countryTargets.Where(t => t.EffectId == effect.Id).Select(t => t.CountryId).ToList();
            var sources = Query(c, "SELECT EffectId,CountryId,EquipmentId FROM GlobalEffectSources",
                r => (EffectId: r.GetInt32(0), Source: new GlobalEffectSource { CountryId = r.GetInt32(1), EquipmentId = r.GetInt32(2) }));
            foreach (var effect in data.GlobalEffects) effect.SourceCategories = sources.Where(t => t.EffectId == effect.Id).Select(t => t.Source).ToList();
            data.Overrides = Query(c, "SELECT CountryId,EquipmentId,Year,Amount FROM StockOverrides",
                r => new StockOverride { CountryId = r.GetInt32(0), EquipmentId = r.GetInt32(1), Year = r.GetInt32(2), Amount = Dec(r, 3) });
            data.Layers = Query(c, "SELECT Id,Year,Type,FileName,OffsetX,OffsetY,Scale,Opacity FROM MapLayers ORDER BY Year,Id",
                r => new MapLayer { Id = r.GetInt32(0), Year = r.GetInt32(1), Type = r.GetString(2), FileName = r.GetString(3),
                    OffsetX = Dec(r, 4), OffsetY = Dec(r, 5), Scale = Dec(r, 6), Opacity = Dec(r, 7) });
            return data;
        }
    }
    public void SaveResourceType(ResourceType x)
    {
        if (string.IsNullOrWhiteSpace(x.Name) || string.IsNullOrWhiteSpace(x.Unit) ||
            string.IsNullOrWhiteSpace(x.IncomeLabel) || string.IsNullOrWhiteSpace(x.UsageLabel) ||
            x.Name.Length > 100 || x.Unit.Length > 40 || x.IncomeLabel.Length > 100 || x.UsageLabel.Length > 100)
            throw new InvalidOperationException("Provide a resource name, unit and the two annual flow labels (within the allowed lengths).");
        lock (gate)
        {
            using var c = Open();
            if (x.Id == 0)
                Execute(c, "INSERT INTO ResourceTypes(Name,Unit,IncomeLabel,UsageLabel) VALUES (@n,@u,@i,@o)",
                    ("@n",x.Name.Trim()),("@u",x.Unit.Trim()),("@i",x.IncomeLabel.Trim()),("@o",x.UsageLabel.Trim()));
            else
                Execute(c, "UPDATE ResourceTypes SET Name=@n,Unit=@u,IncomeLabel=@i,UsageLabel=@o WHERE Id=@id",
                    ("@id",x.Id),("@n",x.Name.Trim()),("@u",x.Unit.Trim()),("@i",x.IncomeLabel.Trim()),("@o",x.UsageLabel.Trim()));
        }
        Raise();
    }
    public void DeleteResourceType(int id)
    {
        lock (gate) { using var c = Open(); Execute(c, "DELETE FROM ResourceTypes WHERE Id=@id", ("@id",id)); }
        Raise();
    }
    public void SaveResourcePlan(ResourcePlan p)
    {
        if (p.CountryId <= 0 || p.ResourceId <= 0 || p.StartYear < 1 || p.AnnualIncome < 0 || p.AnnualUsage < 0)
            throw new InvalidOperationException("Select a country, resource and year; annual income and usage must be nonnegative.");
        lock (gate)
        {
            using var c = Open();
            Execute(c, """
                INSERT INTO ResourcePlans(CountryId,ResourceId,StartYear,StartingStock,AnnualIncome,AnnualUsage)
                VALUES (@c,@r,@y,@s,@i,@u)
                ON CONFLICT(CountryId,ResourceId) DO UPDATE SET StartYear=excluded.StartYear,
                    StartingStock=excluded.StartingStock,AnnualIncome=excluded.AnnualIncome,AnnualUsage=excluded.AnnualUsage
                """, ("@c",p.CountryId),("@r",p.ResourceId),("@y",p.StartYear),
                ("@s",p.StartingStock),("@i",p.AnnualIncome),("@u",p.AnnualUsage));
        }
        Raise();
    }
    public void SetResourceOverride(ResourceOverride x)
    {
        lock (gate)
        {
            using var c = Open();
            Execute(c, """
                INSERT INTO ResourceOverrides(CountryId,ResourceId,Year,Amount) VALUES (@c,@r,@y,@v)
                ON CONFLICT(CountryId,ResourceId,Year) DO UPDATE SET Amount=excluded.Amount
                """, ("@c",x.CountryId),("@r",x.ResourceId),("@y",x.Year),("@v",x.Amount));
        }
        Raise();
    }
    public void RemoveResourceOverride(int countryId,int resourceId,int year)
    {
        lock (gate) { using var c=Open(); Execute(c,
            "DELETE FROM ResourceOverrides WHERE CountryId=@c AND ResourceId=@r AND Year=@y",
            ("@c",countryId),("@r",resourceId),("@y",year)); }
        Raise();
    }
    public void SaveCountry(Country x)
    {
        if (string.IsNullOrWhiteSpace(x.Name) || x.Name.Trim().Length > 100 || x.Name.Trim().Length < 1)
            throw new InvalidOperationException("Country name must contain 1–100 characters.");
        lock (gate)
        {
            using var c = Open();
            if (x.Id == 0) Execute(c, "INSERT INTO Countries(Name) VALUES (@n)", ("@n", x.Name.Trim()));
            else Execute(c, "UPDATE Countries SET Name=@n WHERE Id=@id", ("@n", x.Name.Trim()), ("@id", x.Id));
        }
        // Register the shared country identity after the local database accepts the name.
        accounts.EnsureCountry(x.Name);
        Raise();
    }
    public event Action? CountryPasswordsChanged
    {
        add => accounts.CountryPasswordsChanged += value;
        remove => accounts.CountryPasswordsChanged -= value;
    }
    public string CountryPassword(string name) => accounts.GetCountryPasswordForAdmin(name);
    public void SetCountryPassword(string name, string password) { accounts.SetCountryPassword(name, password); Raise(); }
    public void DeleteCountry(int id)
    {
        lock (gate)
        {
            using var c = Open(); using var tx = c.BeginTransaction();
            Execute(c, tx, "DELETE FROM GlobalEffectSources WHERE CountryId=@id", ("@id", id));
            Execute(c, tx, "DELETE FROM Countries WHERE Id=@id", ("@id", id));
            tx.Commit();
        }
        Raise();
    }
    public void SaveCategory(Category x)
    {
        if (string.IsNullOrWhiteSpace(x.Name) || x.Name.Trim().Length > 100)
            throw new InvalidOperationException("Category name must have 1–100 characters.");
        lock(gate)
        {
            using var c = Open();
            if (x.Id == 0) Execute(c, "INSERT INTO Categories(Name,ShowTotal) VALUES (@n,@t)",
                ("@n",x.Name.Trim()),("@t",x.ShowTotal ? 1 : 0));
            else
            {
                Execute(c,"UPDATE Categories SET Name=@n,ShowTotal=@t WHERE Id=@id",
                    ("@n",x.Name.Trim()),("@t",x.ShowTotal ? 1 : 0),("@id",x.Id));
                Execute(c,"UPDATE Equipment SET GroupName=@n WHERE CategoryId=@id",("@n",x.Name.Trim()),("@id",x.Id));
            }
        }
        Raise();
    }
    public void DeleteCategory(int id)
    {
        lock(gate)
        {
            using var c=Open(); using var tx=c.BeginTransaction();
            // Delete children first; their inventory, overrides and modifier targets cascade.
            Execute(c,tx,"DELETE FROM Equipment WHERE CategoryId=@id",("@id",id));
            Execute(c,tx,"DELETE FROM Categories WHERE Id=@id",("@id",id));
            tx.Commit();
        }
        Raise();
    }
    public void SaveEquipment(Equipment x)
    {
        if (string.IsNullOrWhiteSpace(x.Name) || string.IsNullOrWhiteSpace(x.Unit))
            throw new InvalidOperationException("Sub-type name and unit are required.");
        lock(gate)
        {
            using var c = Open();
            string? group = Scalar(c, "SELECT Name FROM Categories WHERE Id=@id",("@id",x.CategoryId))?.ToString();
            if (group is null) throw new InvalidOperationException("Choose an existing category for this sub-type.");
            if (x.Id == 0) Execute(c, "INSERT INTO Equipment(Name,GroupName,Unit,CategoryId) VALUES (@n,@g,@u,@c)",
                ("@n", x.Name.Trim()), ("@g",group), ("@u",x.Unit.Trim()),("@c",x.CategoryId));
            else Execute(c,"UPDATE Equipment SET Name=@n,GroupName=@g,Unit=@u,CategoryId=@c WHERE Id=@id",
                ("@n",x.Name.Trim()),("@g",group),("@u",x.Unit.Trim()),("@c",x.CategoryId),("@id",x.Id));
        }
        Raise();
    }
    public void DeleteEquipment(int id) { lock (gate) { using var c = Open(); Execute(c, "DELETE FROM Equipment WHERE Id=@id", ("@id", id)); } Raise(); }
    public void SavePlan(StockPlan p)
    {
        lock (gate)
        {
            using var c = Open();
            if (Scalar(c, "SELECT Year FROM Years WHERE Year=@y", ("@y", p.StartYear)) is null)
                throw new InvalidOperationException("Choose a registered baseline year.");
            Execute(c, """
                INSERT INTO Plans(CountryId,EquipmentId,StartYear,StartingStock,AnnualRaw) VALUES (@c,@e,@y,@s,@a)
                ON CONFLICT(CountryId,EquipmentId) DO UPDATE SET StartYear=excluded.StartYear,
                StartingStock=excluded.StartingStock, AnnualRaw=excluded.AnnualRaw
                """, ("@c", p.CountryId), ("@e", p.EquipmentId), ("@y", p.StartYear),
                ("@s", p.StartingStock), ("@a", p.AnnualRaw));
        }
        Raise();
    }
    public void SaveIndividualEffect(IndividualEffect x)
    {
        if (string.IsNullOrWhiteSpace(x.Name)) throw new InvalidOperationException("Effect name is required.");
        if (x.Stage is < 1 or > 2 || (x.Stage == 2 && x.Kind != "Percent") || (x.Kind != "Fixed" && x.Kind != "Percent"))
            throw new InvalidOperationException("Stage 2 permits percentage adjustments only.");
        if (x.FromYear.HasValue && x.ToYear.HasValue && x.FromYear > x.ToYear)
            throw new InvalidOperationException("The end year must be on or after the start year.");
        lock (gate)
        {
            using var c = Open();
            if (x.Id == 0) Execute(c, """
                INSERT INTO IndividualEffects(CountryId,EquipmentId,Name,Stage,Kind,Value,FromYear,ToYear)
                VALUES (@c,@e,@n,@s,@k,@v,@f,@t)
                """, ("@c", x.CountryId), ("@e", x.EquipmentId), ("@n", x.Name.Trim()), ("@s", x.Stage),
                ("@k", x.Kind), ("@v", x.Value), ("@f", x.FromYear), ("@t", x.ToYear));
            else Execute(c, """
                UPDATE IndividualEffects SET Name=@n,Stage=@s,Kind=@k,Value=@v,FromYear=@f,ToYear=@t
                WHERE Id=@id AND CountryId=@c AND EquipmentId=@e
                """, ("@n", x.Name.Trim()), ("@s", x.Stage), ("@k", x.Kind), ("@v", x.Value),
                ("@f", x.FromYear), ("@t", x.ToYear), ("@id", x.Id), ("@c", x.CountryId), ("@e", x.EquipmentId));
        }
        Raise();
    }
    public void DeleteIndividualEffect(int id) { lock (gate) { using var c = Open(); Execute(c, "DELETE FROM IndividualEffects WHERE Id=@id", ("@id", id)); } Raise(); }
    public void SaveGlobalEffect(GlobalEffect x)
    {
        if (string.IsNullOrWhiteSpace(x.Name)) throw new InvalidOperationException("Effect name is required.");
        if (x.Stage is < 1 or > 2 || (x.TargetKind != "Annual" && x.TargetKind != "Stock"))
            throw new InvalidOperationException("Invalid effect stage or target.");
        if (x.FromYear.HasValue && x.ToYear.HasValue && x.FromYear > x.ToYear)
            throw new InvalidOperationException("The end year must be on or after the start year.");
        if (x.TargetDomain is not ("Equipment" or "Resource")) throw new InvalidOperationException("Choose a target domain.");
        if (x.TargetDomain == "Equipment" && x.EquipmentIds.Count == 0)
            throw new InvalidOperationException("Select at least one affected equipment subtype.");
        if (x.TargetDomain == "Resource" && x.ResourceIds.Count == 0)
            throw new InvalidOperationException("Select at least one affected resource.");
        if (x.ValueMode is not ("Percent" or "Fixed" or "CategoryStock" or "EquipmentAnnual" or "EquipmentRate")) throw new InvalidOperationException("Choose a valid effect calculation mode.");
        if ((x.ValueMode is "CategoryStock" or "EquipmentAnnual" or "EquipmentRate") && x.SourceCategories.Count == 0)
            throw new InvalidOperationException("Select at least one source category (either default or for each country).");
        if ((x.ValueMode is "EquipmentAnnual" or "EquipmentRate") && x.TargetDomain != "Resource")
            throw new InvalidOperationException("Equipment annual change can only feed resource effects.");
        if (x.Description.Length > 1200) throw new InvalidOperationException("Description is limited to 1200 characters.");
        lock (gate)
        {
            using var c = Open(); using var tx = c.BeginTransaction();
            // Transactions are also serialised by the process-level repository lock.
            int id = x.Id;
            if (id == 0)
            {
                Execute(c, tx, "INSERT INTO GlobalEffects(Name,Stage,TargetKind,Percent,FromYear,ToYear,Description,ValueMode,TargetDomain) VALUES (@n,@s,@t,@p,@f,@to,@d,@vm,@domain)",
                    ("@n", x.Name.Trim()), ("@s", x.Stage), ("@t", x.TargetKind), ("@p", x.Percent),
                    ("@f", x.FromYear), ("@to", x.ToYear), ("@d", x.Description.Trim()), ("@vm", x.ValueMode), ("@domain", x.TargetDomain));
                id = Convert.ToInt32(Scalar(c, tx, "SELECT last_insert_rowid()"));
            }
            else Execute(c, tx, "UPDATE GlobalEffects SET Name=@n,Stage=@s,TargetKind=@t,Percent=@p,FromYear=@f,ToYear=@to,Description=@d,ValueMode=@vm,TargetDomain=@domain WHERE Id=@id",
                ("@n", x.Name.Trim()), ("@s", x.Stage), ("@t", x.TargetKind), ("@p", x.Percent),
                ("@f", x.FromYear), ("@to", x.ToYear), ("@d", x.Description.Trim()), ("@vm", x.ValueMode), ("@domain", x.TargetDomain), ("@id", id));
            Execute(c, tx, "DELETE FROM GlobalEffectTargets WHERE EffectId=@id", ("@id", id));
            foreach (int equipmentId in x.EquipmentIds.Distinct())
                Execute(c, tx, "INSERT INTO GlobalEffectTargets(EffectId,EquipmentId) VALUES (@id,@eq)", ("@id", id), ("@eq", equipmentId));
            Execute(c, tx, "DELETE FROM GlobalEffectResourceTargets WHERE EffectId=@id", ("@id", id));
            foreach (int resourceId in x.ResourceIds.Distinct())
                Execute(c, tx, "INSERT INTO GlobalEffectResourceTargets(EffectId,ResourceId) VALUES (@id,@r)", ("@id", id), ("@r", resourceId));
            Execute(c, tx, "DELETE FROM GlobalEffectCountryTargets WHERE EffectId=@id", ("@id", id));
            foreach (int countryId in x.CountryIds.Distinct())
                Execute(c, tx, "INSERT INTO GlobalEffectCountryTargets(EffectId,CountryId) VALUES (@id,@country)", ("@id", id), ("@country", countryId));
            Execute(c, tx, "DELETE FROM GlobalEffectSources WHERE EffectId=@id", ("@id", id));
            foreach (var source in x.SourceCategories.Select(y => (y.CountryId, y.EquipmentId)).Distinct())
            {
                if (source.CountryId < 0) throw new InvalidOperationException("Invalid source country.");
                Execute(c, tx, "INSERT INTO GlobalEffectSources(EffectId,CountryId,EquipmentId) VALUES (@id,@country,@category)",
                    ("@id", id), ("@country", source.CountryId), ("@category", source.EquipmentId));
            }
            tx.Commit();
        }
        Raise();
    }
    public void DeleteGlobalEffect(int id) { lock (gate) { using var c = Open(); Execute(c, "DELETE FROM GlobalEffects WHERE Id=@id", ("@id", id)); } Raise(); }
    public void SetOverride(StockOverride x)
    {
        lock (gate)
        {
            using var c = Open();
            Execute(c, """
                INSERT INTO StockOverrides(CountryId,EquipmentId,Year,Amount) VALUES (@c,@e,@y,@v)
                ON CONFLICT(CountryId,EquipmentId,Year) DO UPDATE SET Amount=excluded.Amount
                """, ("@c", x.CountryId), ("@e", x.EquipmentId), ("@y", x.Year), ("@v", Math.Round(x.Amount, 0, MidpointRounding.AwayFromZero)));
        }
        Raise();
    }
    public void RemoveOverride(int countryId, int equipmentId, int year)
    {
        lock (gate) { using var c = Open(); Execute(c, "DELETE FROM StockOverrides WHERE CountryId=@c AND EquipmentId=@e AND Year=@y",
            ("@c", countryId), ("@e", equipmentId), ("@y", year)); }
        Raise();
    }
    public void SaveMap(MapLayer map)
    {
        if (!new[] { "Base", "Topography", "Territory", "CountryNames", "Logistics" }.Contains(map.Type))
            throw new InvalidOperationException("Unknown map layer type.");
        if (map.Scale <= 0 || map.Scale > 10 || map.Opacity < 0 || map.Opacity > 1 || Math.Abs(map.OffsetX) > 1000 || Math.Abs(map.OffsetY) > 1000)
            throw new InvalidOperationException("Invalid layer position, scale or opacity.");
        lock (gate)
        {
            using var c = Open();
            if (map.Id > 0)
                Execute(c, "UPDATE MapLayers SET OffsetX=@x,OffsetY=@y,Scale=@s,Opacity=@o WHERE Id=@id",
                    ("@x", map.OffsetX), ("@y", map.OffsetY), ("@s", map.Scale), ("@o", map.Opacity), ("@id", map.Id));
            else
                Execute(c, """
                    INSERT INTO MapLayers(Year,Type,FileName,OffsetX,OffsetY,Scale,Opacity)
                    VALUES (@year,@type,@file,@x,@y,@s,@o)
                    ON CONFLICT(Year,Type) DO UPDATE SET FileName=excluded.FileName,
                        OffsetX=excluded.OffsetX,OffsetY=excluded.OffsetY,Scale=excluded.Scale,Opacity=excluded.Opacity
                    """, ("@year", map.Year), ("@type", map.Type), ("@file", map.FileName),
                    ("@x", map.OffsetX), ("@y", map.OffsetY), ("@s", map.Scale), ("@o", map.Opacity));
        }
        Raise();
    }
    public void DeleteMap(int id) { lock (gate) { using var c = Open(); Execute(c, "DELETE FROM MapLayers WHERE Id=@id", ("@id", id)); } Raise(); }
    public bool IsKnownMapFile(string fileName)
    {
        lock (gate) { using var c = Open(); return Scalar(c, "SELECT Id FROM MapLayers WHERE FileName=@f LIMIT 1", ("@f", fileName)) is not null; }
    }
    public void Dispose() => catalog.DataUpdated -= OnScenarioUpdated;
}
