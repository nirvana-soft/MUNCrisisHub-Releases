using HistoricalAtlas.Domain;
using Microsoft.Data.Sqlite;
using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.DataProtection;

namespace HistoricalAtlas.Services;

// One shared account database across every scenario. Scenario ZIP archives NEVER contain accounts.
public sealed class AccountStore
{
    private readonly object gate = new();
    private readonly string path;
    // Keep encryption keys with App_Data so moving the Visual Studio project does not
    // change which keys decrypt country credentials. The key folder must be backed up
    // together with accounts.sqlite; never put it in a public download or export.
    private const string StablePasswordPrefix = "v2:";
    private readonly IDataProtector secrets;
    private readonly IDataProtector legacySecrets;
    private readonly IDataProtector tickets;
    public event Action? CountryPasswordsChanged;
    public AccountStore(IHostEnvironment environment, IDataProtectionProvider protection)
    {
        string dir = Path.Combine(environment.ContentRootPath, "App_Data");
        Directory.CreateDirectory(dir);
        path = Path.Combine(dir, "accounts.sqlite");
        legacySecrets = protection.CreateProtector("HistoricalAtlas.CountryPassword.v1");
        string keyDirectory = Path.Combine(dir, "data-protection-keys");
        Directory.CreateDirectory(keyDirectory);
        // Stable application name AND persisted key ring, independent of ContentRootPath.
        // Legacy passwords are migrated when their old key is still available.
        var persistent = DataProtectionProvider.Create(new DirectoryInfo(keyDirectory),
            setup => setup.SetApplicationName("HistoricalAtlas.CountryAccess"));
        secrets = persistent.CreateProtector("HistoricalAtlas.CountryPassword.v2");
        tickets = persistent.CreateProtector("HistoricalAtlas.CountryAccessTicket.v2");
    }
    private SqliteConnection Open()
    {
        var c = new SqliteConnection($"Data Source={path}"); c.Open(); return c;
    }
    private static SqliteCommand Command(SqliteConnection c, string sql, params (string, object?)[] parameters)
    {
        var cmd = c.CreateCommand(); cmd.CommandText = sql;
        foreach (var (name,value) in parameters) cmd.Parameters.AddWithValue(name, value ?? DBNull.Value);
        return cmd;
    }
    private static (string salt,string hash) Hash(string password)
    {
        var salt = RandomNumberGenerator.GetBytes(16);
        var hash = Rfc2898DeriveBytes.Pbkdf2(password,salt,210_000,HashAlgorithmName.SHA256,32);
        return (Convert.ToBase64String(salt),Convert.ToBase64String(hash));
    }
    public void Initialize()
    {
        lock (gate)
        {
            using var c=Open(); using var cmd=Command(c,"CREATE TABLE IF NOT EXISTS Users (Id INTEGER PRIMARY KEY AUTOINCREMENT, Username TEXT NOT NULL UNIQUE COLLATE NOCASE, Salt TEXT NOT NULL, Hash TEXT NOT NULL, Role TEXT NOT NULL DEFAULT 'User')"); cmd.ExecuteNonQuery();
            using (var countryTable=Command(c,"CREATE TABLE IF NOT EXISTS CountryCredentials (Name TEXT NOT NULL PRIMARY KEY COLLATE NOCASE, ProtectedPassword TEXT NOT NULL, Revision INTEGER NOT NULL DEFAULT 1)")) countryTable.ExecuteNonQuery();
            // Non-destructive upgrade: retain every account and existing password hash.
            // The reserved 'admin' account is the sole Site Administrator.
            using (var migrate=Command(c,"UPDATE Users SET Role='ScenarioManager' WHERE Role IN ('Admin','SiteAdmin') AND Username <> 'admin' COLLATE NOCASE")) migrate.ExecuteNonQuery();
            using (var root=Command(c,"UPDATE Users SET Role='SiteAdmin' WHERE Username='admin' COLLATE NOCASE AND Role <> 'SiteAdmin'")) root.ExecuteNonQuery();
            using var n=Command(c,"SELECT COUNT(*) FROM Users WHERE Username='admin' COLLATE NOCASE");
            if(Convert.ToInt32(n.ExecuteScalar())==0)
            {
                string? passwordFile = Environment.GetEnvironmentVariable("ATLAS_BOOTSTRAP_PASSWORD_FILE");
                string? initialPassword = string.IsNullOrWhiteSpace(passwordFile)
                    ? Environment.GetEnvironmentVariable("ATLAS_BOOTSTRAP_PASSWORD")
                    : File.ReadAllText(passwordFile).Trim();
                if (string.IsNullOrWhiteSpace(initialPassword))
                {
                    // Standalone source downloads also need a usable first run. Keep the
                    // generated secret outside wwwroot and never include it in console logs.
                    string generatedFile = Path.Combine(Path.GetDirectoryName(path)!, "initial-admin-password.txt");
                    if (File.Exists(generatedFile)) initialPassword = File.ReadAllText(generatedFile).Trim();
                    else
                    {
                        initialPassword = Convert.ToBase64String(RandomNumberGenerator.GetBytes(24));
                        var options = new FileStreamOptions { Mode = FileMode.CreateNew, Access = FileAccess.Write, Share = FileShare.None };
                        if (!OperatingSystem.IsWindows()) options.UnixCreateMode = UnixFileMode.UserRead | UnixFileMode.UserWrite;
                        using var file = new FileStream(generatedFile, options);
                        using var writer = new StreamWriter(file);
                        writer.Write(initialPassword);
                    }
                    Console.WriteLine($"First-run administrator account: username admin. Read its generated password from {generatedFile}. Keep this file private; it is not served by the website.");
                }
                if (initialPassword.Length < 8)
                    throw new InvalidOperationException("Administrator password must contain at least 8 characters. Set ATLAS_BOOTSTRAP_PASSWORD or ATLAS_BOOTSTRAP_PASSWORD_FILE, or check App_Data/initial-admin-password.txt.");
                var (salt,hash)=Hash(initialPassword);
                using var add=Command(c,"INSERT INTO Users(Username,Salt,Hash,Role) VALUES ('admin',@s,@h,'SiteAdmin')",("@s",salt),("@h",hash));
                add.ExecuteNonQuery();
            }
        }
    }
    public Account? Authenticate(string username,string password)
    {
        lock(gate)
        {
            using var c=Open();using var cmd=Command(c,"SELECT Id,Username,Role,Salt,Hash FROM Users WHERE Username=@u",("@u",username));using var r=cmd.ExecuteReader();
            if(!r.Read())return null;
            var salt=Convert.FromBase64String(r.GetString(3));var expected=Convert.FromBase64String(r.GetString(4));
            var hash=Rfc2898DeriveBytes.Pbkdf2(password,salt,210_000,HashAlgorithmName.SHA256,32);
            if(!CryptographicOperations.FixedTimeEquals(hash,expected))return null;
            return new Account{Id=r.GetInt32(0),Username=r.GetString(1),Role=r.GetString(2)};
        }
    }
    public Account? Register(string username,string password)
    {
        if(string.IsNullOrWhiteSpace(username)||username.Length is <3 or >32||password.Length<8||!username.All(ch=>char.IsLetterOrDigit(ch)||ch is '_' or '-' or '.'))return null;
        lock(gate)
        {
            using var c=Open();using var check=Command(c,"SELECT Id FROM Users WHERE Username=@u",("@u",username));if(check.ExecuteScalar()!=null)return null;
            var(salt,hash)=Hash(password);using var insert=Command(c,"INSERT INTO Users(Username,Salt,Hash,Role) VALUES (@u,@s,@h,'User')",("@u",username),("@s",salt),("@h",hash));insert.ExecuteNonQuery();
            using var id=Command(c,"SELECT last_insert_rowid()");return new Account{Id=Convert.ToInt32(id.ExecuteScalar()),Username=username,Role="User"};
        }
    }
    public Account? GetAccount(int id)
    {
        lock(gate)
        {
            using var c=Open();using var cmd=Command(c,"SELECT Id,Username,Role FROM Users WHERE Id=@i",("@i",id));using var r=cmd.ExecuteReader();
            return r.Read()?new Account{Id=r.GetInt32(0),Username=r.GetString(1),Role=r.GetString(2)}:null;
        }
    }
    public List<Account> Accounts()
    {
        var list=new List<Account>();lock(gate)
        {
            using var c=Open();using var cmd=Command(c,"SELECT Id,Username,Role FROM Users ORDER BY Username");using var r=cmd.ExecuteReader();
            while(r.Read())list.Add(new Account{Id=r.GetInt32(0),Username=r.GetString(1),Role=r.GetString(2)});
        }return list;
    }
    public void SetRole(int id,string role)
    {
        if(role is not (AtlasRoles.ScenarioManager or AtlasRoles.User))
            throw new InvalidOperationException("Only User and Scenario Manager roles may be assigned. The Site Administrator is reserved.");
        lock(gate)
        {
            using var c=Open();
            using var current=Command(c,"SELECT Username, Role FROM Users WHERE Id=@i",("@i",id));
            using var reader=current.ExecuteReader();
            if (!reader.Read()) throw new InvalidOperationException("Account not found.");
            if (reader.GetString(0).Equals("admin", StringComparison.OrdinalIgnoreCase) || reader.GetString(1)==AtlasRoles.SiteAdmin)
                throw new InvalidOperationException("The Site Administrator account cannot be reassigned.");
            reader.Close();
            using var update=Command(c,"UPDATE Users SET Role=@r WHERE Id=@i",("@r",role),("@i",id));update.ExecuteNonQuery();
        }
    }
    /// <summary>Explicit local recovery; caller supplies a private file, never a shared default.</summary>
    public void ResetAdministratorPasswordFromFile(string passwordFile)
    {
        if (string.IsNullOrWhiteSpace(passwordFile)) throw new InvalidOperationException("Specify a private password file for administrator recovery.");
        string password = File.ReadAllText(Path.GetFullPath(passwordFile)).Trim();
        if (password.Length < 8) throw new InvalidOperationException("The recovery password must contain at least eight characters.");
        var administrator = Accounts().Single(a => a.Username.Equals("admin", StringComparison.OrdinalIgnoreCase));
        SetPassword(administrator.Id, password);
    }
    public void SetPassword(int id,string password)
    {
        if(password.Length<8)throw new InvalidOperationException("Password must be at least eight characters.");
        var(salt,hash)=Hash(password);lock(gate)
        {
            using var c=Open();using var update=Command(c,"UPDATE Users SET Salt=@s,Hash=@h WHERE Id=@i",("@s",salt),("@h",hash),("@i",id));update.ExecuteNonQuery();
        }
    }
    private static string NormalizeCountry(string name)
    {
        name = name.Trim();
        if (name.Length is < 1 or > 100) throw new InvalidOperationException("Country name must contain 1–100 characters.");
        return name;
    }
    private static string RandomAccessPassword()
    {
        const string alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
        return new string(Enumerable.Range(0, 6).Select(_ => alphabet[RandomNumberGenerator.GetInt32(alphabet.Length)]).ToArray());
    }
    // Reads both new, portable credentials and older credentials issued by the
    // previous app. If the legacy key remains accessible, migrate without changing
    // the password. If it is lost, throw CryptographicException so the admin UI
    // can request an explicit reset rather than silently revoking access.
    private string ReadCountryPassword(SqliteConnection c, string countryName, string ciphertext)
    {
        if (ciphertext.StartsWith(StablePasswordPrefix, StringComparison.Ordinal))
            return secrets.Unprotect(ciphertext[StablePasswordPrefix.Length..]);
        string plaintext = legacySecrets.Unprotect(ciphertext);
        using var upgrade = Command(c,
            "UPDATE CountryCredentials SET ProtectedPassword=@new WHERE Name=@name AND ProtectedPassword=@old",
            ("@new", StablePasswordPrefix + secrets.Protect(plaintext)),
            ("@name", countryName), ("@old", ciphertext));
        upgrade.ExecuteNonQuery();
        return plaintext;
    }
    /// <summary>One global country record, reused by every scenario with the same name.</summary>
    public void EnsureCountry(string countryName)
    {
        string name = NormalizeCountry(countryName);
        lock (gate)
        {
            using var c = Open();
            using var check = Command(c, "SELECT 1 FROM CountryCredentials WHERE Name=@name", ("@name", name));
            if (check.ExecuteScalar() is not null) return;
            using var add = Command(c, "INSERT OR IGNORE INTO CountryCredentials(Name,ProtectedPassword,Revision) VALUES(@name,@password,1)",
                ("@name",name),("@password",StablePasswordPrefix + secrets.Protect(RandomAccessPassword())));
            add.ExecuteNonQuery();
        }
    }
    /// <summary>Return cleartext only to the authenticated AdminInventory component.</summary>
    public string GetCountryPasswordForAdmin(string countryName)
    {
        EnsureCountry(countryName);
        lock (gate)
        {
            using var c = Open();
            using var cmd = Command(c,"SELECT ProtectedPassword FROM CountryCredentials WHERE Name=@name",("@name",NormalizeCountry(countryName)));
            var stored = cmd.ExecuteScalar()?.ToString() ?? throw new InvalidOperationException("Country not found.");
            return ReadCountryPassword(c, NormalizeCountry(countryName), stored);
        }
    }
    public void SetCountryPassword(string countryName, string password)
    {
        if (password.Length is < 6 or > 128 || password.Any(char.IsWhiteSpace))
            throw new InvalidOperationException("Country password must be 6–128 characters without spaces.");
        EnsureCountry(countryName);
        lock (gate)
        {
            using var c = Open();
            using var cmd = Command(c,"UPDATE CountryCredentials SET ProtectedPassword=@p, Revision=Revision+1 WHERE Name=@n",
                ("@p",StablePasswordPrefix + secrets.Protect(password)),("@n",NormalizeCountry(countryName)));
            cmd.ExecuteNonQuery();
        }
        CountryPasswordsChanged?.Invoke();
    }
    /// <summary>
    /// Resolve a password against countries that actually occur in the active scenario.
    /// Never return a country if the same password unlocks multiple country identities.
    /// Results are sent only after authentication by the caller.
    /// </summary>
    public string? MatchCountryPassword(string password, IEnumerable<string> scenarioCountries)
    {
        if (string.IsNullOrEmpty(password)) return null;
        string? match = null;
        foreach (var country in scenarioCountries.Distinct(StringComparer.OrdinalIgnoreCase))
        {
            if (!VerifyCountryPassword(country, password)) continue;
            if (match is not null) return null;
            match = country;
        }
        return match;
    }

    public bool VerifyCountryPassword(string countryName, string password)
    {
        if (string.IsNullOrWhiteSpace(password)) return false;
        lock (gate)
        {
            using var c = Open();
            using var cmd = Command(c,"SELECT ProtectedPassword FROM CountryCredentials WHERE Name=@n",("@n",countryName.Trim()));
            if (cmd.ExecuteScalar() is not string encrypted) return false;
            try
            {
                byte[] actual = Encoding.UTF8.GetBytes(ReadCountryPassword(c, NormalizeCountry(countryName), encrypted));
                byte[] proposed = Encoding.UTF8.GetBytes(password);
                return actual.Length == proposed.Length && CryptographicOperations.FixedTimeEquals(actual,proposed);
            }
            catch (CryptographicException)
            {
                // An old password may have been encrypted under a now-lost key.
                // Do not crash the public password endpoint or silently regenerate it.
                return false;
            }
        }
    }
    public static string CountryCookieName(string countryName)
    {
        var hash = SHA256.HashData(Encoding.UTF8.GetBytes(countryName.Trim().ToUpperInvariant()));
        return "atlas-country-" + Convert.ToHexString(hash.AsSpan(0, 10)).ToLowerInvariant();
    }
    public string IssueAccessTicket(string countryName)
    {
        lock (gate)
        {
            using var c = Open();
            using var cmd = Command(c,"SELECT Revision FROM CountryCredentials WHERE Name=@n",("@n",countryName.Trim()));
            var revision = Convert.ToInt32(cmd.ExecuteScalar() ?? throw new InvalidOperationException("Unknown country."));
            return tickets.Protect(countryName.Trim().ToUpperInvariant() + "|" + revision);
        }
    }
    public bool HasCountryAccess(string countryName, string? ticket)
    {
        if (string.IsNullOrEmpty(ticket)) return false;
        try
        {
            lock (gate)
            {
                using var c = Open();
                using var cmd = Command(c,"SELECT Revision FROM CountryCredentials WHERE Name=@n",("@n",countryName.Trim()));
                if (cmd.ExecuteScalar() is not object revision) return false;
                var expected = countryName.Trim().ToUpperInvariant() + "|" + Convert.ToInt32(revision);
                var actual = tickets.Unprotect(ticket);
                return string.Equals(expected, actual, StringComparison.Ordinal);
            }
        }
        catch (System.Security.Cryptography.CryptographicException) { return false; }
    }
}
