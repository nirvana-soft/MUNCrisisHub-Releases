using HistoricalAtlas.Domain;
using System.Security.Claims;
using Microsoft.Data.Sqlite;
using System.IO.Compression;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace HistoricalAtlas.Services;

public sealed class ScenarioEntry
{
    public string Slug { get; set; } = "";
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    public DateTime CreatedUtc { get; set; }
    public int CreatorUserId { get; set; }
    public List<int> ManagerUserIds { get; set; } = new();
    public List<int> VisitorUserIds { get; set; } = new();
}

/// <summary>
/// Each scenario is physically isolated in its own SQLite database and uploads folder.
/// The catalog and global account database are NOT included in exports.
/// </summary>
public sealed class ScenarioCatalog
{
    private readonly object gate = new();
    private readonly string root;
    private readonly string catalogFile;
    private readonly string defaultScenarioFile;
    private readonly string demoImages;
    private readonly AccountStore globalAccounts;
    private List<ScenarioEntry> scenarios = new();
    private static readonly JsonSerializerOptions json = new() { WriteIndented = true, PropertyNameCaseInsensitive = true };
    public event Action<string>? DataUpdated;
    public event Action? CatalogUpdated;
    public const string DefaultSlug = "demo-1960s";
    public ScenarioCatalog(IHostEnvironment host, AccountStore globalAccounts)
    {
        this.globalAccounts=globalAccounts;
        root = Path.Combine(host.ContentRootPath,"App_Data","scenarios");
        catalogFile = Path.Combine(root,"catalog.json");
        defaultScenarioFile = Path.Combine(root,"default-scenario.txt");
        demoImages = Path.Combine(host.ContentRootPath,"SampleData","maps");
    }
    public static string? SlugFromPath(string path)
    {
        var segments = path.Split('/', StringSplitOptions.RemoveEmptyEntries);
        if (segments.Length == 0 || segments[0] is "scenarios" or "login" or "register" or "auth" or "api" or "error" or "map-file" or "_framework" or "css" or "js" or "images" or "choose" or "site-admin" or "welcome" or "account")
            return null;
        return segments[0].ToLowerInvariant();
    }
    public string ScenarioDirectory(string slug)
    {
        if(!ValidSlug(slug))throw new InvalidOperationException("Invalid scenario address.");
        return Path.Combine(root, slug.ToLowerInvariant());
    }
    public static bool ValidSlug(string slug) => Regex.IsMatch(slug, @"^[a-z0-9][a-z0-9-]{0,59}$", RegexOptions.CultureInvariant) && SlugFromPath("/"+slug) != null && slug is not "logistics" and not "admin";
    public void Initialize()
    {
        lock(gate)
        {
            Directory.CreateDirectory(root);
            if(File.Exists(catalogFile))scenarios = JsonSerializer.Deserialize<List<ScenarioEntry>>(File.ReadAllText(catalogFile),json) ?? new();
            foreach(var s in scenarios) {s.ManagerUserIds ??= new(); s.VisitorUserIds ??= new();}
            // New installations start without a scenario; the demo is optional and can be imported manually.
            if(!File.Exists(catalogFile)) SaveCatalog();
            // Retry filesystem cleanup after an interrupted Windows deletion, without
            // accidentally deleting registered scenarios or the catalog itself.
            foreach (var folder in Directory.GetDirectories(root))
            {
                string candidate=Path.GetFileName(folder);
                if (candidate.StartsWith(".deleted-", StringComparison.Ordinal) ||
                    File.Exists(Path.Combine(folder, ".atlas-delete-pending")))
                    try { Directory.Delete(folder,true); } catch (IOException) { } catch (UnauthorizedAccessException) { }
            }
        }
    }
    /// <summary>Register country identities from all existing scenario databases on startup.</summary>
    public void RegisterExistingCountries()
    {
        foreach (var scenario in List())
        {
            var dbPath = Path.Combine(ScenarioDirectory(scenario.Slug), "scenario.sqlite");
            if (!File.Exists(dbPath)) continue;
            using var db = new SqliteConnection($"Data Source={dbPath};Mode=ReadOnly");
            db.Open();
            using var cmd = db.CreateCommand();
            cmd.CommandText = "SELECT Name FROM Countries";
            using var r = cmd.ExecuteReader();
            while (r.Read()) globalAccounts.EnsureCountry(r.GetString(0));
        }
    }
    private void SaveCatalog()
    {
        var temporary=catalogFile+".tmp";
        File.WriteAllText(temporary,JsonSerializer.Serialize(scenarios,json));
        File.Move(temporary,catalogFile,true);
    }
    /// <summary>Admin default is stored separately from scenario exports and survives restarts.</summary>
    public string? GetDefaultScenarioSlug()
    {
        lock (gate)
        {
            string? saved = File.Exists(defaultScenarioFile) ? File.ReadAllText(defaultScenarioFile).Trim() : null;
            if (saved is not null && scenarios.Any(s => s.Slug.Equals(saved, StringComparison.OrdinalIgnoreCase)))
                return scenarios.First(s => s.Slug.Equals(saved, StringComparison.OrdinalIgnoreCase)).Slug;
            // Backward compatibility: existing users who had the demo keep it as the
            // admin default, but guests still never auto-open it.
            return scenarios.FirstOrDefault(s => s.Slug == DefaultSlug)?.Slug
                ?? scenarios.OrderBy(s => s.CreatedUtc).FirstOrDefault()?.Slug;
        }
    }
    public void SetDefaultScenario(string slug)
    {
        lock (gate)
        {
            if (!scenarios.Any(s => s.Slug.Equals(slug, StringComparison.OrdinalIgnoreCase)))
                throw new InvalidOperationException("Choose an existing scenario as the default.");
            File.WriteAllText(defaultScenarioFile, slug.ToLowerInvariant());
            CatalogUpdated?.Invoke();
        }
    }
    public List<ScenarioEntry> List()
    {
        lock(gate)return scenarios.Select(Clone).OrderBy(s=>s.Name).ToList();
    }
    private static ScenarioEntry Clone(ScenarioEntry x)=>new(){Slug=x.Slug,Name=x.Name,Description=x.Description,CreatedUtc=x.CreatedUtc,
        CreatorUserId=x.CreatorUserId, ManagerUserIds=new(x.ManagerUserIds),VisitorUserIds=new(x.VisitorUserIds)};
    private static int UserId(ClaimsPrincipal principal) =>
        int.TryParse(principal.FindFirst(ClaimTypes.NameIdentifier)?.Value, out int id) ? id : 0;
    public bool CanManage(string slug, ClaimsPrincipal user)
    {
        if (user.IsInRole(AtlasRoles.SiteAdmin)) return true;
        int id=UserId(user);
        if (id==0) return false;
        lock(gate) { var s=scenarios.FirstOrDefault(x=>x.Slug==slug);return s is not null &&
            (s.CreatorUserId==id || s.ManagerUserIds.Contains(id)); }
    }
    public bool IsCreator(string slug, ClaimsPrincipal user)
    {
        if (user.IsInRole(AtlasRoles.SiteAdmin))return true;
        int id=UserId(user);
        lock(gate) return id!=0 && scenarios.Any(s=>s.Slug==slug && s.CreatorUserId==id);
    }
    public bool CanCreate(ClaimsPrincipal user) =>
        user.IsInRole(AtlasRoles.SiteAdmin) || user.IsInRole(AtlasRoles.ScenarioManager);
    public List<ScenarioEntry> VisibleTo(ClaimsPrincipal user) =>
        List().Where(s=>CanManage(s.Slug,user)).ToList();
    public List<ScenarioEntry> VisitedBy(ClaimsPrincipal user)
    {
        int id = UserId(user);
        if (id == 0) return new();
        return List().Where(s => s.VisitorUserIds.Contains(id) && !CanManage(s.Slug, user)).ToList();
    }
    public List<Account> VisitedAccounts(string slug, ClaimsPrincipal requester)
    {
        if (!CanManage(slug,requester))throw new UnauthorizedAccessException("Only scenario managers can manage this team.");
        lock(gate)
        {
            var s=scenarios.FirstOrDefault(x=>x.Slug==slug)??throw new InvalidOperationException("Scenario not found.");
            return s.VisitorUserIds.Distinct().Select(id=>globalAccounts.GetAccount(id)).OfType<Account>()
                .Where(a=>a.Id!=s.CreatorUserId && a.Role!=AtlasRoles.SiteAdmin).OrderBy(a=>a.Username).ToList();
        }
    }
    public void RecordVisit(string slug, ClaimsPrincipal user)
    {
        int id=UserId(user);if(id==0)return;
        lock(gate)
        {
            var s=scenarios.FirstOrDefault(x=>x.Slug==slug);if(s is null || s.VisitorUserIds.Contains(id))return;
            s.VisitorUserIds.Add(id);SaveCatalog();CatalogUpdated?.Invoke();
        }
    }
    public void SetManager(string slug, int accountId, bool enabled, ClaimsPrincipal actor)
    {
        if(!CanManage(slug,actor))throw new UnauthorizedAccessException("Only scenario managers can assign or revoke other managers.");
        lock(gate)
        {
            var s=scenarios.FirstOrDefault(x=>x.Slug==slug)??throw new InvalidOperationException("Scenario not found.");
            var account=globalAccounts.GetAccount(accountId)??throw new InvalidOperationException("Account not found.");
            if(account.Role==AtlasRoles.SiteAdmin || accountId==s.CreatorUserId)
                throw new InvalidOperationException("The creator and Site Administrator already have management access.");
            if(!s.VisitorUserIds.Contains(accountId))throw new InvalidOperationException("Only an account that has visited this scenario may be assigned.");
            if(enabled && !s.ManagerUserIds.Contains(accountId))s.ManagerUserIds.Add(accountId);
            if(!enabled)s.ManagerUserIds.Remove(accountId);
            SaveCatalog();CatalogUpdated?.Invoke();
        }
    }
    public ScenarioEntry? Get(string slug)
    {
        lock(gate)return scenarios.Where(x=>x.Slug.Equals(slug,StringComparison.OrdinalIgnoreCase)).Select(Clone).FirstOrDefault();
    }
    public ScenarioEntry Create(string name,string slug,string description,int creatorUserId=0)
    {
        slug=slug.Trim().ToLowerInvariant();name=name.Trim();
        if(name.Length is <2 or >100||!ValidSlug(slug))throw new InvalidOperationException("Enter a name (2–100 characters) and a URL slug using lowercase letters, digits and hyphens.");
        lock(gate)
        {
            if(scenarios.Any(x=>x.Slug==slug))throw new InvalidOperationException("That scenario URL is already in use.");
            if(Directory.Exists(ScenarioDirectory(slug)))throw new InvalidOperationException("The scenario folder already exists.");
            var entry=new ScenarioEntry{Slug=slug,Name=name,Description=description.Trim(),CreatedUtc=DateTime.UtcNow,CreatorUserId=creatorUserId};
            Directory.CreateDirectory(ScenarioDirectory(slug));
            bool first = scenarios.Count == 0;
            scenarios.Add(entry);SaveCatalog();
            if (first) File.WriteAllText(defaultScenarioFile, entry.Slug);
            CatalogUpdated?.Invoke();return Clone(entry);
        }
    }
    public void Update(string slug,string name,string description)
    {
        if(string.IsNullOrWhiteSpace(name)||name.Length>100)throw new InvalidOperationException("Invalid name.");
        lock(gate)
        {
            var item=scenarios.FirstOrDefault(x=>x.Slug==slug)??throw new InvalidOperationException("Scenario not found.");
            item.Name=name.Trim();item.Description=description.Trim();SaveCatalog();CatalogUpdated?.Invoke();
        }
    }
    public void Delete(string slug)
    {
        lock(gate)
        {
            if(scenarios.Count<=1)throw new InvalidOperationException("You must keep at least one scenario.");
            var item=scenarios.FirstOrDefault(x=>x.Slug==slug)??throw new InvalidOperationException("Scenario not found.");
            // Remove from the public catalog first. On Windows the active Blazor circuit
            // may briefly hold an open SQLite handle; that must not make the UI deletion fail.
            // Stale physical files are retried when the application next starts.
            scenarios.Remove(item);
            try { SaveCatalog(); }
            catch { scenarios.Add(item); throw; }
            // Deleted defaults are cleared, so the remaining scenario becomes the admin fallback.
            if (File.Exists(defaultScenarioFile) && File.ReadAllText(defaultScenarioFile).Trim().Equals(slug,StringComparison.OrdinalIgnoreCase))
                File.Delete(defaultScenarioFile);
            string folder=ScenarioDirectory(slug);
            try { if(Directory.Exists(folder))Directory.Delete(folder,true); }
            catch (IOException) { try { File.WriteAllText(Path.Combine(folder,".atlas-delete-pending"),"1"); } catch { } }
            catch (UnauthorizedAccessException) { try { File.WriteAllText(Path.Combine(folder,".atlas-delete-pending"),"1"); } catch { } }
            CatalogUpdated?.Invoke();
        }
    }
    public void NotifyDataUpdated(string slug)=>DataUpdated?.Invoke(slug);

    public void EnsureDemo(AccountStore users)
    {
        var entry=Get(DefaultSlug);if(entry is null)return;
        string marker = Path.Combine(ScenarioDirectory(DefaultSlug), ".demo-seeded");
        if (File.Exists(marker)) return;
        using var db=new AtlasStore(this,users,DefaultSlug);db.Initialize();
        if(db.Snapshot().Countries.Count>0) { File.WriteAllText(marker,"seeded"); return; }
        db.SaveSettings("1960s Strategic Demo","Illustrative Middle East — fictional data, not historical claims");
        db.AddYear(1965);db.AddYear(1970);
        foreach(string c in new[]{"Turkey","Iran","Iraq","Soviet Union"})db.SaveCountry(new Country{Name=c});
        foreach(var (name,total) in new [] { ("Manpower",true), ("Deployed Troops",true), ("Available Equipment",false) })
            db.SaveCategory(new Category{Name=name,ShowTotal=total});
        var categories=db.Snapshot().Categories;
        foreach(var (cat,name,unit) in new[] {
            ("Manpower", "Available Manpower", "personnel"),
            ("Manpower", "Reserve Manpower", "personnel"),
            ("Manpower", "Trained Manpower", "personnel"),
            ("Deployed Troops", "Infantry Division", "personnel"),
            ("Deployed Troops", "Armored Division", "personnel"),
            ("Deployed Troops", "Support Units", "personnel"),
            ("Available Equipment", "Infantry Equipment", "sets"),
            ("Available Equipment", "Artillery", "pieces"),
            ("Available Equipment", "Armored Vehicles", "vehicles"),
            ("Available Equipment", "Ammunition", "crates"),
            ("Available Equipment", "Fuel", "liters")
        }) db.SaveEquipment(new Equipment { Name=name,CategoryId=categories.First(c=>c.Name==cat).Id, Unit=unit });
        var snap=db.Snapshot();
        string[] order=["Turkey","Iran","Iraq","Soviet Union"];
        decimal[] countryScale = [1m, 1.2m, .8m, 4m];
        var bases=new Dictionary<string, (decimal Stock, decimal Annual)> {
            ["Available Manpower"]=(250000,10000), ["Reserve Manpower"]=(125000,4000), ["Trained Manpower"]=(80000,4500),
            ["Infantry Division"]=(65000,3000),["Armored Division"]=(15000,800),["Support Units"]=(24000,1100),
            ["Infantry Equipment"]=(70000,10000),["Artillery"]=(1500,120),["Armored Vehicles"]=(980,34),
            ["Ammunition"]=(9000,1200),["Fuel"]=(250000,18000)
        };
        foreach (var (country,index) in snap.Countries.OrderBy(c=>Array.IndexOf(order,c.Name)).Select((c,i)=>(c,i)))
        foreach(var subtype in snap.Equipment)
        {
            var values=bases[subtype.Name];
            db.SavePlan(new StockPlan{CountryId=country.Id,EquipmentId=subtype.Id,StartYear=1960,
                StartingStock=Math.Round(values.Stock*countryScale[index],0),
                AnnualRaw=Math.Round(values.Annual*countryScale[index],0)});
        }
        var turkey=snap.Countries.First(c=>c.Name=="Turkey");
        var iran=snap.Countries.First(c=>c.Name=="Iran");
        var iraq=snap.Countries.First(c=>c.Name=="Iraq");
        var trained=snap.Equipment.First(c=>c.Name=="Trained Manpower");
        var infantry=snap.Equipment.First(c=>c.Name=="Infantry Division");
        var vehicle=snap.Equipment.First(c=>c.Name=="Armored Vehicles");
        db.SaveIndividualEffect(new IndividualEffect{CountryId=iran.Id,EquipmentId=trained.Id,
            Name="Industrial training",Stage=1,Kind="Percent",Value=15});
        db.SaveIndividualEffect(new IndividualEffect{CountryId=iraq.Id,EquipmentId=infantry.Id,
            Name="Mobilization",Stage=1,Kind="Percent",Value=12,FromYear=1964});
        db.SaveGlobalEffect(new GlobalEffect{Name="Industrial Uplift",Description="Investment increases equipment production.",
            Stage=1,TargetKind="Annual",Percent=15,FromYear=1962,
            EquipmentIds=snap.Equipment.Where(e=>e.CategoryId==categories.First(c=>c.Name=="Available Equipment").Id).Select(e=>e.Id).ToList(),
            CountryIds=[turkey.Id,iran.Id]});
        db.SaveGlobalEffect(new GlobalEffect{Name="Ongoing War",Description="Annual usage equals 40% of prior-year deployed troop stock.",
            Stage=2,TargetKind="Annual",ValueMode="CategoryStock",Percent=-40,FromYear=1965,ToYear=1970,
            EquipmentIds=snap.Equipment.Select(e=>e.Id).ToList(), CountryIds=[iraq.Id,iran.Id],
            SourceCategories=snap.Equipment.Where(e=>e.CategoryId==categories.First(c=>c.Name=="Deployed Troops").Id)
                .Select(e=>new GlobalEffectSource{CountryId=0,EquipmentId=e.Id}).ToList()});
        db.SaveGlobalEffect(new GlobalEffect{Name="Supply Efficiency",Description="Logistics modernization improves stock efficiency.",
            Stage=1,TargetKind="Stock",Percent=2,FromYear=1966,ToYear=1968,EquipmentIds=[vehicle.Id]});
        db.SetOverride(new StockOverride{CountryId=turkey.Id,EquipmentId=vehicle.Id,Year=1965,Amount=1500});
        foreach(int year in new[]{1960,1965,1970})
        foreach(var type in new[]{"Base","Topography","Logistics","Territory"})
        {
            string source=Path.Combine(demoImages,$"demo_{year}_{type.ToLowerInvariant()}.png");
            if(!File.Exists(source))continue;
            string file=$"demo_{year}_{type.ToLowerInvariant()}.png";
            File.Copy(source,Path.Combine(db.UploadDirectory,file),true);
            db.SaveMap(new MapLayer{Year=year,Type=type,FileName=file,Opacity=type=="Territory"?0.80m:1m,Scale=1});
        }
        File.WriteAllText(marker, "seeded");
    }

    // All exports must be round-trip safe. We compare the logical contents of the
    // live database, its SQLite backup and the DB embedded in the final archive.
    // This prevents silently downloading a valid-looking but empty dataset.
    private static readonly string[] SnapshotTables =
    [
        "Years", "Settings", "Countries", "Categories", "Equipment", "Plans",
        "IndividualEffects", "GlobalEffects", "GlobalEffectTargets",
        "GlobalEffectCountryTargets", "GlobalEffectSources", "GlobalEffectResourceTargets", "StockOverrides", "MapLayers", "ResourceTypes", "ResourcePlans", "ResourceOverrides"
    ];

    private static Dictionary<string, long> ReadScenarioCounts(string database)
    {
        var counts = new Dictionary<string, long>(StringComparer.Ordinal);
        using var connection = new SqliteConnection(new SqliteConnectionStringBuilder
        {
            DataSource = database, Mode = SqliteOpenMode.ReadOnly, Pooling = false
        }.ToString());
        connection.Open();
        using (var integrity = connection.CreateCommand())
        {
            integrity.CommandText = "PRAGMA integrity_check";
            if (integrity.ExecuteScalar()?.ToString() != "ok")
                throw new InvalidOperationException("Scenario database failed its integrity check.");
        }
        foreach (string table in SnapshotTables)
        {
            using var exists = connection.CreateCommand();
            exists.CommandText = "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=@n";
            exists.Parameters.AddWithValue("@n", table);
            if (Convert.ToInt32(exists.ExecuteScalar()) == 0) continue; // older scenario schemas
            using var query = connection.CreateCommand();
            query.CommandText = $"SELECT COUNT(*) FROM \"{table}\"";
            counts[table] = Convert.ToInt64(query.ExecuteScalar());
        }
        return counts;
    }

    private static void AssertSameScenarioCounts(IReadOnlyDictionary<string, long> expected,
        IReadOnlyDictionary<string, long> observed)
    {
        foreach (var (table, count) in expected)
        {
            if (!observed.TryGetValue(table, out long actual) || actual != count)
                throw new InvalidOperationException(
                    $"Scenario export failed verification: {table} has {count} records in the live " +
                    $"scenario but {actual} in the downloaded snapshot. Export was cancelled.");
        }
    }

    public byte[] Export(string slug)
    {
        if (Get(slug) is not ScenarioEntry entry)
            throw new InvalidOperationException("Scenario not found.");

        string folder = ScenarioDirectory(slug);
        string database = Path.Combine(folder, "scenario.sqlite");
        if (!File.Exists(database))
            throw new InvalidOperationException("No scenario database exists.");

        // Capture the live scenario contents BEFORE snapshotting. If those values
        // do not make it into the archive, fail loudly rather than export a blank save.
        var originalCounts = ReadScenarioCounts(database);
        string temp = Path.Combine(Path.GetTempPath(), "atlas-" + Guid.NewGuid().ToString("N") + ".sqlite");
        try
        {
            // Back up the live scenario while it is being used. SQLite connections
            // to the TEMPORARY snapshot must have pooling disabled. Otherwise
            // Dispose() only returns them to the pool and Windows keeps temp locked.
            var sourceOptions = new SqliteConnectionStringBuilder
            {
                DataSource = database,
                Mode = SqliteOpenMode.ReadOnly,
                Pooling = false
            }.ToString();
            var snapshotOptions = new SqliteConnectionStringBuilder
            {
                DataSource = temp,
                Mode = SqliteOpenMode.ReadWriteCreate,
                Pooling = false
            }.ToString();
            using (var source = new SqliteConnection(sourceOptions))
            using (var target = new SqliteConnection(snapshotOptions))
            {
                source.Open();
                target.Open();
                source.BackupDatabase(target);
            }

            var snapshotCounts = ReadScenarioCounts(temp);
            AssertSameScenarioCounts(originalCounts, snapshotCounts);

            var files = new List<string>();
            var readOnlySnapshotOptions = new SqliteConnectionStringBuilder
            {
                DataSource = temp,
                Mode = SqliteOpenMode.ReadOnly,
                Pooling = false
            }.ToString();
            using (var copy = new SqliteConnection(readOnlySnapshotOptions))
            {
                copy.Open();
                using var command = copy.CreateCommand();
                command.CommandText = "SELECT DISTINCT FileName FROM MapLayers";
                using var reader = command.ExecuteReader();
                while (reader.Read()) files.Add(reader.GetString(0));
            }

            // Read only after BOTH snapshot connections are fully disposed.
            // The ZIP writer no longer needs to open a live SQLite file.
            byte[] snapshotBytes = File.ReadAllBytes(temp);
            using var output = new MemoryStream();
            using (var zip = new ZipArchive(output, ZipArchiveMode.Create, leaveOpen: true))
            {
                var meta = zip.CreateEntry("scenario.json");
                using (var writer = new StreamWriter(meta.Open()))
                    writer.Write(JsonSerializer.Serialize(new {entry.Slug,entry.Name,entry.Description,entry.CreatedUtc,Contents=snapshotCounts},json));

                var databaseEntry = zip.CreateEntry("scenario.sqlite", CompressionLevel.Optimal);
                using (var destination = databaseEntry.Open())
                    destination.Write(snapshotBytes);

                foreach (var name in files)
                {
                    if (Path.GetFileName(name) != name || name.Contains(".."))
                        throw new InvalidOperationException("Invalid map filename in database.");
                    string image = Path.Combine(folder, "uploads", name);
                    if (!File.Exists(image))
                        throw new InvalidOperationException($"Missing map image: {name}");
                    zip.CreateEntryFromFile(image, "maps/" + name);
                }
            }
            var archiveBytes = output.ToArray();
            // Validate the exact byte stream delivered to the browser, not merely
            // a temporary backup that could fail to be packaged correctly.
            using (var verifyArchive = new ZipArchive(new MemoryStream(archiveBytes), ZipArchiveMode.Read))
            {
                var zippedDb = verifyArchive.GetEntry("scenario.sqlite")
                    ?? throw new InvalidOperationException("Export archive is missing the scenario database.");
                using var zipRead = zippedDb.Open();
                using var contents = new MemoryStream();
                zipRead.CopyTo(contents);
                if (!System.Security.Cryptography.SHA256.HashData(contents.ToArray())
                    .AsSpan().SequenceEqual(System.Security.Cryptography.SHA256.HashData(snapshotBytes)))
                    throw new InvalidOperationException("Export archive database content mismatch.");
                if (verifyArchive.Entries.Count(e => e.FullName.StartsWith("maps/", StringComparison.Ordinal)) != files.Count)
                    throw new InvalidOperationException("Export archive is missing map layers.");
            }
            return archiveBytes;
        }
        finally
        {
            // Snapshot connections above are unpooled, so Windows can release
            // and delete this temporary database immediately.
            if (File.Exists(temp)) File.Delete(temp);
        }
    }
    public ScenarioEntry Import(byte[] bytes,string name,string slug,string description,int creatorUserId=0)
    {
        if(bytes.Length>100*1024*1024)throw new InvalidOperationException("Scenario archive exceeds 100 MB.");
        slug=slug.Trim().ToLowerInvariant();
        if(!ValidSlug(slug)||name.Trim().Length is <2 or >100)throw new InvalidOperationException("Enter a valid scenario name and URL slug.");
        lock(gate)
        {
            if(scenarios.Any(s=>s.Slug==slug)||Directory.Exists(ScenarioDirectory(slug)))throw new InvalidOperationException("That scenario URL already exists.");
            string folder=ScenarioDirectory(slug);
            Directory.CreateDirectory(Path.Combine(folder,"uploads"));
            try
            {
                using var input=new MemoryStream(bytes);using var zip=new ZipArchive(input,ZipArchiveMode.Read);
                if(zip.Entries.Count>1000 || zip.Entries.Sum(e=>e.Length)>200*1024*1024)throw new InvalidOperationException("Archive is too large.");
                var db=zip.GetEntry("scenario.sqlite")??throw new InvalidOperationException("Not a scenario archive: scenario.sqlite is missing.");
                if(db.Length>50*1024*1024)throw new InvalidOperationException("Scenario database is too large.");
                foreach(var file in zip.Entries)
                {
                    if(file.FullName is "scenario.sqlite" or "scenario.json")continue;
                    if(!file.FullName.StartsWith("maps/",StringComparison.Ordinal)||file.FullName.Length<=5)
                        throw new InvalidOperationException("Unexpected archive entry.");
                    string basename=file.FullName[5..];
                    if(Path.GetFileName(basename)!=basename||basename.Contains("..")||!IsImageName(basename)||file.Length>15*1024*1024)
                        throw new InvalidOperationException("Invalid map image in archive.");
                }
                using(var dest=File.Create(Path.Combine(folder,"scenario.sqlite")))using(var from=db.Open())from.CopyTo(dest);
                foreach(var entry in zip.Entries.Where(x=>x.FullName.StartsWith("maps/",StringComparison.Ordinal)))
                {
                    var basename=entry.FullName[5..];
                    byte[] content;using(var src=entry.Open())using(var buffer=new MemoryStream()){src.CopyTo(buffer);content=buffer.ToArray();}
                    if(!ValidImage(content,basename))throw new InvalidOperationException("Map file has invalid PNG/JPEG contents.");
                    File.WriteAllBytes(Path.Combine(folder,"uploads",basename),content);
                }
                ValidateImportedDatabase(Path.Combine(folder,"scenario.sqlite"),Path.Combine(folder,"uploads"));
                // New archives carry a manifest of actual table counts. Reject
                // incomplete/empty exports while continuing to accept older saves.
                var metaEntry = zip.GetEntry("scenario.json");
                if (metaEntry is not null)
                {
                    using var metadataStream = metaEntry.Open();
                    using var metadata = JsonDocument.Parse(metadataStream);
                    if (metadata.RootElement.TryGetProperty("Contents", out var manifest) &&
                        manifest.ValueKind == JsonValueKind.Object)
                    {
                        var expected = new Dictionary<string, long>();
                        foreach (var field in manifest.EnumerateObject())
                        {
                            if (!SnapshotTables.Contains(field.Name) || !field.Value.TryGetInt64(out long count) || count < 0)
                                throw new InvalidOperationException("Invalid scenario export manifest.");
                            expected[field.Name] = count;
                        }
                        AssertSameScenarioCounts(expected, ReadScenarioCounts(Path.Combine(folder,"scenario.sqlite")));
                    }
                }
                using (var imported = new SqliteConnection($"Data Source={Path.Combine(folder, "scenario.sqlite")};Mode=ReadOnly"))
                {
                    imported.Open();
                    using var names = imported.CreateCommand();
                    names.CommandText = "SELECT Name FROM Countries";
                    using var reader = names.ExecuteReader();
                    while (reader.Read()) globalAccounts.EnsureCountry(reader.GetString(0));
                }
                var created=new ScenarioEntry{Slug=slug,Name=name.Trim(),Description=description.Trim(),CreatedUtc=DateTime.UtcNow,CreatorUserId=creatorUserId};
                bool first = scenarios.Count == 0;
                scenarios.Add(created);SaveCatalog();
                if (first) File.WriteAllText(defaultScenarioFile, created.Slug);
                CatalogUpdated?.Invoke();return Clone(created);
            }
            catch
            {
                try{Directory.Delete(folder,true);}catch{}
                throw;
            }
        }
    }
    /// <summary>
    /// Replaces the simulation content of one EXISTING scenario from a .atlas.zip
    /// dataset. The scenario slug, creator, visitors and manager assignments are
    /// catalog metadata and are never replaced. A verified backup is stored on disk
    /// before modifying the live SQLite database or its maps.
    /// </summary>
    public string ReplaceDataset(string slug, byte[] bytes, ClaimsPrincipal actor)
    {
        if (!CanManage(slug, actor))
            throw new UnauthorizedAccessException("You are not a manager of this scenario.");
        if (bytes.Length == 0 || bytes.Length > 100 * 1024 * 1024)
            throw new InvalidOperationException("Select a scenario archive up to 100 MB.");
        lock (gate)
        {
            if (scenarios.All(s => s.Slug != slug))
                throw new InvalidOperationException("Scenario not found.");
            string liveDir = ScenarioDirectory(slug);
            string liveDb = Path.Combine(liveDir, "scenario.sqlite");
            string liveUploads = Path.Combine(liveDir, "uploads");
            if (!File.Exists(liveDb))
                throw new InvalidOperationException("Current scenario has no database to back up.");

            string stageDir = Path.Combine(root, ".import-" + Guid.NewGuid().ToString("N"));
            string stageUploads = Path.Combine(stageDir, "maps");
            string stageDb = Path.Combine(stageDir, "scenario.sqlite");
            var addedImages = new List<string>();
            byte[]? recoveryArchive = null;
            bool databaseModified = false;
            Directory.CreateDirectory(stageUploads);
            try
            {
                using (var input = new MemoryStream(bytes))
                using (var zip = new ZipArchive(input, ZipArchiveMode.Read))
                {
                    if (zip.Entries.Count > 1000 || zip.Entries.Sum(e => e.Length) > 200L * 1024 * 1024)
                        throw new InvalidOperationException("The archive contains too many or oversized files.");
                    var databaseEntry = zip.GetEntry("scenario.sqlite")
                        ?? throw new InvalidOperationException("This archive has no scenario.sqlite database.");
                    if (databaseEntry.Length > 50L * 1024 * 1024)
                        throw new InvalidOperationException("The scenario database exceeds the 50 MB limit.");
                    foreach (var file in zip.Entries)
                    {
                        if (file.FullName is "scenario.sqlite" or "scenario.json") continue;
                        if (!file.FullName.StartsWith("maps/", StringComparison.Ordinal) || file.FullName.Length <= 5)
                            throw new InvalidOperationException("Unexpected file in scenario archive.");
                        string name = file.FullName[5..];
                        if (name != Path.GetFileName(name) || name.Contains("..") ||
                            name.Length > 160 || !IsImageName(name) || file.Length > 15L * 1024 * 1024)
                            throw new InvalidOperationException("The archive contains an invalid map filename or image size.");
                    }
                    using (var destination = File.Create(stageDb))
                    using (var source = databaseEntry.Open()) source.CopyTo(destination);
                    foreach (var file in zip.Entries.Where(e => e.FullName.StartsWith("maps/", StringComparison.Ordinal)))
                    {
                        string name = file.FullName[5..];
                        using var source = file.Open();
                        using var memory = new MemoryStream();
                        source.CopyTo(memory);
                        byte[] content = memory.ToArray();
                        if (!ValidImage(content, name))
                            throw new InvalidOperationException("Invalid PNG/JPEG image in the archive.");
                        File.WriteAllBytes(Path.Combine(stageUploads, name), content);
                    }
                    ValidateImportedDatabase(stageDb, stageUploads);
                    // Verify the export manifest when supplied, as in normal imports.
                    var metadata = zip.GetEntry("scenario.json");
                    if (metadata is not null)
                    {
                        using var content = metadata.Open();
                        using var jsonDocument = JsonDocument.Parse(content);
                        if (jsonDocument.RootElement.TryGetProperty("Contents", out var manifest) &&
                            manifest.ValueKind == JsonValueKind.Object)
                        {
                            var expected = new Dictionary<string, long>();
                            foreach (var field in manifest.EnumerateObject())
                            {
                                if (!SnapshotTables.Contains(field.Name) ||
                                    !field.Value.TryGetInt64(out long count) || count < 0)
                                    throw new InvalidOperationException("Invalid scenario export manifest.");
                                expected[field.Name] = count;
                            }
                            AssertSameScenarioCounts(expected, ReadScenarioCounts(stageDb));
                        }
                    }
                }

                // Never begin replacement unless a complete export of the old
                // scenario exists. This backup is not included in dataset exports.
                recoveryArchive = Export(slug);
                string backupDir = Path.Combine(liveDir, "backups");
                Directory.CreateDirectory(backupDir);
                string backupName = $"{slug}-before-import-{DateTime.UtcNow:yyyyMMdd-HHmmss}-{Guid.NewGuid():N}.atlas.zip";
                File.WriteAllBytes(Path.Combine(backupDir, backupName), recoveryArchive);

                // Give incoming map files unique names. Existing uploads remain
                // untouched, including while the current scenario is in use.
                Directory.CreateDirectory(liveUploads);
                using (var staged = new SqliteConnection(new SqliteConnectionStringBuilder {
                    DataSource = stageDb, Mode = SqliteOpenMode.ReadWrite, Pooling = false
                }.ToString()))
                {
                    staged.Open();
                    var names = new List<string>();
                    using (var command = staged.CreateCommand())
                    {
                        command.CommandText = "SELECT DISTINCT FileName FROM MapLayers";
                        using var reader = command.ExecuteReader();
                        while (reader.Read()) names.Add(reader.GetString(0));
                    }
                    foreach (var name in names)
                    {
                        string newName = "import-" + Guid.NewGuid().ToString("N")[..12] + "-" + name;
                        string destination = Path.Combine(liveUploads, newName);
                        File.Copy(Path.Combine(stageUploads, name), destination, false);
                        addedImages.Add(destination);
                        using var update = staged.CreateCommand();
                        update.CommandText = "UPDATE MapLayers SET FileName=@new WHERE FileName=@old";
                        update.Parameters.AddWithValue("@new", newName);
                        update.Parameters.AddWithValue("@old", name);
                        update.ExecuteNonQuery();
                    }
                }

                // SQLite's online backup API safely replaces contents without
                // relying on renaming/deleting a database used by other requests.
                databaseModified = true;
                CopyDatabase(stageDb, liveDb);
                using (var current = new AtlasStore(this, globalAccounts, slug))
                    current.Initialize(); // handles older archive schema versions
                ValidateImportedDatabase(liveDb, liveUploads);
                RegisterCountriesFromDatabase(liveDb);
                NotifyDataUpdated(slug);
                return backupName;
            }
            catch (Exception failure)
            {
                if (databaseModified && recoveryArchive is not null)
                {
                    try
                    {
                        string restoreDb = Path.Combine(stageDir, "recovery.sqlite");
                        using (var original = new ZipArchive(new MemoryStream(recoveryArchive), ZipArchiveMode.Read))
                        using (var contents = original.GetEntry("scenario.sqlite")!.Open())
                        using (var destination = File.Create(restoreDb)) contents.CopyTo(destination);
                        CopyDatabase(restoreDb, liveDb);
                    }
                    catch (Exception restoreFailure)
                    {
                        // Keep newly uploaded files if restoration failed. The
                        // durable backup above can still be used to recover.
                        throw new InvalidOperationException(
                            "Import failed and automatic database recovery also failed. " +
                            "Restore the backup stored in this scenario's backups folder. " +
                            restoreFailure.Message, failure);
                    }
                }
                foreach (string image in addedImages)
                    try { File.Delete(image); } catch (IOException) { } catch (UnauthorizedAccessException) { }
                throw;
            }
            finally
            {
                try { Directory.Delete(stageDir, recursive: true); }
                catch (IOException) { } catch (UnauthorizedAccessException) { }
            }
        }
    }

    private static void CopyDatabase(string sourcePath, string destinationPath)
    {
        var sourceSettings = new SqliteConnectionStringBuilder {
            DataSource = sourcePath, Mode = SqliteOpenMode.ReadOnly, Pooling = false
        }.ToString();
        var destinationSettings = new SqliteConnectionStringBuilder {
            DataSource = destinationPath, Mode = SqliteOpenMode.ReadWrite, Pooling = false
        }.ToString();
        using var source = new SqliteConnection(sourceSettings);
        using var destination = new SqliteConnection(destinationSettings);
        source.Open();
        destination.Open();
        source.BackupDatabase(destination);
    }

    private void RegisterCountriesFromDatabase(string databasePath)
    {
        using var db = new SqliteConnection(new SqliteConnectionStringBuilder {
            DataSource = databasePath, Mode = SqliteOpenMode.ReadOnly, Pooling = false
        }.ToString());
        db.Open();
        using var cmd = db.CreateCommand();
        cmd.CommandText = "SELECT Name FROM Countries";
        using var r = cmd.ExecuteReader();
        while (r.Read()) globalAccounts.EnsureCountry(r.GetString(0));
    }

    private static bool IsImageName(string filename)=>filename.EndsWith(".png",StringComparison.OrdinalIgnoreCase)||filename.EndsWith(".jpg",StringComparison.OrdinalIgnoreCase)||filename.EndsWith(".jpeg",StringComparison.OrdinalIgnoreCase);
    private static bool ValidImage(byte[] b,string name)=>name.EndsWith(".png",StringComparison.OrdinalIgnoreCase)
        ? b.Length>=8&&b[0]==137&&b[1]==80&&b[2]==78&&b[3]==71&&b[4]==13&&b[5]==10&&b[6]==26&&b[7]==10
        : b.Length>=3&&b[0]==255&&b[1]==216&&b[2]==255;
    private static void ValidateImportedDatabase(string dbpath,string uploads)
    {
        using var c=new SqliteConnection(new SqliteConnectionStringBuilder{DataSource=dbpath,Mode=SqliteOpenMode.ReadOnly,Pooling=false}.ToString());c.Open();
        using(var integrity=c.CreateCommand()){integrity.CommandText="PRAGMA integrity_check";if(integrity.ExecuteScalar()?.ToString()!="ok")throw new InvalidOperationException("The imported database is corrupt.");}
        using(var cmd=c.CreateCommand())
        {
            cmd.CommandText="SELECT type,name FROM sqlite_master WHERE type IN ('trigger','view')";
            using var r=cmd.ExecuteReader();if(r.Read())throw new InvalidOperationException("Scenario archives cannot contain database triggers or views.");
        }
        foreach(var table in new[]{"Years","Settings","Countries","Equipment","Plans","IndividualEffects","GlobalEffects","GlobalEffectTargets","GlobalEffectCountryTargets","StockOverrides","MapLayers"})
        {
            using var cmd=c.CreateCommand();cmd.CommandText="SELECT count(*) FROM sqlite_master WHERE type='table' AND name=@name";cmd.Parameters.AddWithValue("@name",table);
            if(Convert.ToInt32(cmd.ExecuteScalar())!=1)throw new InvalidOperationException("Incompatible scenario archive: missing "+table);
        }
        using(var foreign=c.CreateCommand()){foreign.CommandText="PRAGMA foreign_key_check";using var r=foreign.ExecuteReader();if(r.Read())throw new InvalidOperationException("Invalid foreign keys in the imported scenario.");}
        using(var maps=c.CreateCommand())
        {
            maps.CommandText="SELECT DISTINCT FileName FROM MapLayers";using var r=maps.ExecuteReader();
            while(r.Read())
            {
                var name=r.GetString(0);
                if(Path.GetFileName(name)!=name||!IsImageName(name)||!File.Exists(Path.Combine(uploads,name)))throw new InvalidOperationException("Missing or invalid map referenced by the database.");
            }
        }
        using(var years=c.CreateCommand()){years.CommandText="SELECT COUNT(*) FROM Years";if(Convert.ToInt32(years.ExecuteScalar())<1)throw new InvalidOperationException("An imported scenario must have at least one year.");}
    }
}
