using System.Security.Claims;

namespace HistoricalAtlas.Services;

/// <summary>Application-level roles. Scenario content management is separate from site security.</summary>
public static class AtlasRoles
{
    public const string SiteAdmin = "SiteAdmin";
    public const string ScenarioManager = "ScenarioManager";
    public const string User = "User";
    public const string Editors = SiteAdmin + "," + ScenarioManager; // legacy role labels, not scenario-wide permissions
    public static bool CanEditScenarios(this ClaimsPrincipal principal) =>
        principal.IsInRole(SiteAdmin) || principal.IsInRole(ScenarioManager);
    public static bool CanManageSite(this ClaimsPrincipal principal) => principal.IsInRole(SiteAdmin);
}
