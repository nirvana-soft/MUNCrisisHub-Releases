using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.HttpOverrides;
using HistoricalAtlas.Components;
using Microsoft.AspNetCore.Components;
using HistoricalAtlas.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Security.Claims;
using Microsoft.AspNetCore.RateLimiting;
using System.Threading.RateLimiting;

var builder = WebApplication.CreateBuilder(args);
builder.WebHost.UseWebRoot("wwwroot");
builder.Services.AddRazorComponents().AddInteractiveServerComponents();
builder.Services.AddCascadingAuthenticationState();
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/login";
        options.AccessDeniedPath = "/login";
        options.Cookie.Name = "HistoricalAtlas.Session";
        options.Cookie.HttpOnly = true;
        options.Cookie.SameSite = SameSiteMode.Lax;
        options.ExpireTimeSpan = TimeSpan.FromHours(10);
        options.SlidingExpiration = true;
        // Ensure role changes take effect when a browser next makes an authenticated request.
        options.Events.OnValidatePrincipal = context =>
        {
            var raw = context.Principal?.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!int.TryParse(raw, out int id)) { context.RejectPrincipal(); return Task.CompletedTask; }
            var account = context.HttpContext.RequestServices.GetRequiredService<AccountStore>().GetAccount(id);
            if (account is null || account.Role != context.Principal?.FindFirst(ClaimTypes.Role)?.Value ||
                account.Username != context.Principal?.FindFirst(ClaimTypes.Name)?.Value)
                context.RejectPrincipal();
            return Task.CompletedTask;
        };
    });
builder.Services.AddAuthorization();
builder.Services.AddRateLimiter(options =>
{
    options.AddPolicy("country-password", context => RateLimitPartition.GetFixedWindowLimiter(
        context.Connection.RemoteIpAddress?.ToString() ?? "unknown", _ => new FixedWindowRateLimiterOptions
        { PermitLimit = 12, Window = TimeSpan.FromMinutes(1), QueueLimit = 0 }));
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
});
// Hosting manager persists session keys separately from country-access keys.
var protection = builder.Services.AddDataProtection();
var keyPath = builder.Configuration["Hosting:SessionKeyPath"];
if (!string.IsNullOrWhiteSpace(keyPath))
    protection.PersistKeysToFileSystem(new DirectoryInfo(keyPath)).SetApplicationName("HistoricalAtlas.Web");
builder.Services.Configure<ForwardedHeadersOptions>(options =>
{
    options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
    // cloudflared shares the website network namespace and connects over loopback.
    // Keep the framework's loopback-only trust list; never trust arbitrary proxies.
    options.ForwardLimit = 1;
});
builder.Services.AddSingleton<ScenarioCatalog>();
builder.Services.AddSingleton<AccountStore>();
builder.Services.AddScoped<AtlasStore>(sp =>
{
    var catalog = sp.GetRequiredService<ScenarioCatalog>();
    var nav = sp.GetRequiredService<NavigationManager>();
    var requestedSlug = ScenarioCatalog.SlugFromPath(new Uri(nav.Uri).AbsolutePath);
    var slug = requestedSlug is not null && catalog.Get(requestedSlug) is not null
        ? requestedSlug
        : throw new InvalidOperationException("Select a registered scenario before opening the atlas.");
    var store = new AtlasStore(catalog, sp.GetRequiredService<AccountStore>(), slug);
    store.Initialize();
    return store;
});
builder.Services.AddScoped<TimelineState>();

var app = builder.Build();
app.UseForwardedHeaders();
var catalog = app.Services.GetRequiredService<ScenarioCatalog>();
var accounts = app.Services.GetRequiredService<AccountStore>();
accounts.Initialize();
catalog.Initialize();
catalog.RegisterExistingCountries();
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/error");
}
// CSS/JS changes are revalidated instead of being served from an old browser cache.
app.UseStaticFiles(new StaticFileOptions
{
    OnPrepareResponse = context =>
        context.Context.Response.Headers.CacheControl = "no-cache, must-revalidate"
});
app.UseRouting();
app.UseAuthentication();
app.UseRateLimiter();
app.UseAuthorization();
// Record only authenticated registered visits. A visit never grants editing authority.
app.Use(async (http,next) =>
{
    if (http.User.Identity?.IsAuthenticated==true)
    {
        var current=ScenarioCatalog.SlugFromPath(http.Request.Path.Value ?? "");
        if (current is not null && catalog.Get(current) is not null)
            catalog.RecordVisit(current,http.User);
    }
    await next();
});
app.UseAntiforgery();

// A bare URL never opens the demo or silently reuses an old dataset.
// Administrators get their configured default; other users see the sign-in/account gateway.
app.MapGet("/", (HttpContext http, ScenarioCatalog scenarios) =>
{
    if (!http.User.IsInRole(AtlasRoles.SiteAdmin))
        return Results.Redirect(http.User.Identity?.IsAuthenticated == true ? "/account" : "/login");
    var slug = scenarios.GetDefaultScenarioSlug();
    return Results.Redirect(slug is null ? "/scenarios" : "/" + slug);
});
// The former public scenario directory is not a public navigation destination.
app.MapGet("/choose", (HttpContext http) => Results.Redirect(http.User.Identity?.IsAuthenticated == true ? "/account" : "/login"));
app.MapGet("/admin", () => Results.Redirect("/"));
app.MapGet("/logistics", () => Results.Redirect("/"));

app.MapPost("/auth/login", async (HttpContext http, AccountStore db) =>
{
    var form = await http.Request.ReadFormAsync();
    string name = form["username"].ToString().Trim();
    string password = form["password"].ToString();
    var account = db.Authenticate(name, password);
    if (account is null) return Results.Redirect("/login?error=invalid");
    var claims = new List<Claim> {
        new(ClaimTypes.NameIdentifier, account.Id.ToString()),
        new(ClaimTypes.Name, account.Username),
        new(ClaimTypes.Role, account.Role)
    };
    var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
    await http.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));
    return Results.Redirect(account.Role == AtlasRoles.SiteAdmin ? "/" : "/account");
});

app.MapPost("/auth/register", async (HttpContext http, AccountStore db) =>
{
    var form = await http.Request.ReadFormAsync();
    string username = form["username"].ToString().Trim();
    string password = form["password"].ToString();
    string confirm = form["confirm"].ToString();
    if (password != confirm || password.Length < 8 || username.Length < 3 || username.Length > 32)
        return Results.Redirect("/register?error=invalid");
    var account = db.Register(username, password);
    if (account is null) return Results.Redirect("/register?error=taken");
    var identity = new ClaimsIdentity(new [] {
        new Claim(ClaimTypes.NameIdentifier, account.Id.ToString()),
        new Claim(ClaimTypes.Name, account.Username),
        new Claim(ClaimTypes.Role, account.Role)
    }, CookieAuthenticationDefaults.AuthenticationScheme);
    await http.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));
    return Results.Redirect(account.Role == AtlasRoles.SiteAdmin ? "/" : "/account");
});

app.MapPost("/auth/logout", async (HttpContext http) =>
{
    await http.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
    return Results.Redirect("/");
});

app.MapGet("/map-file/{slug}/{fileName}", (HttpContext http,string slug, string fileName, ScenarioCatalog scenarios, AccountStore accounts) =>
{
    if (Path.GetFileName(fileName) != fileName || scenarios.Get(slug) is null) return Results.NotFound();
    using var db = new AtlasStore(scenarios, accounts, slug);
    db.Initialize();
    var allowedByPublicYear = int.TryParse(http.Request.Query["year"].ToString(), out var publicYear)
        && db.IsCountryNamesVisibleInPublicYear(fileName, publicYear);
    if (!db.IsKnownMapFile(fileName) || (!scenarios.CanManage(slug,http.User)
        && !db.IsPublicMapFile(fileName) && !allowedByPublicYear)) return Results.NotFound();
    var fullPath = Path.Combine(db.UploadDirectory, fileName);
    if (!File.Exists(fullPath)) return Results.NotFound();
    var contentType = fileName.EndsWith(".png", StringComparison.OrdinalIgnoreCase) ? "image/png" : "image/jpeg";
    return Results.File(fullPath, contentType, enableRangeProcessing: true);
});

// Export contains only scenario inventory, effect rules and image layers — never accounts.
app.MapGet("/scenarios/export/{slug}", (HttpContext http,string slug, ScenarioCatalog scenarios) =>
{
    if (scenarios.Get(slug) is null) return Results.NotFound();
    if (!scenarios.CanManage(slug,http.User)) return Results.Forbid();
    return Results.File(scenarios.Export(slug), "application/zip", $"{slug}.atlas.zip");
}).RequireAuthorization();

// Country access is shared across scenarios and does not require a user login.
app.MapGet("/access/check", (HttpContext http, string country, AccountStore accounts) =>
{
    if (http.User.IsInRole(AtlasRoles.SiteAdmin)) return Results.Ok(new { allowed = true });
    string cookieName = AccountStore.CountryCookieName(country);
    return Results.Ok(new { allowed = accounts.HasCountryAccess(country, http.Request.Cookies[cookieName]) });
});

// Only returns countries for which this browser already has a valid signed ticket.
// The route never exposes the full list of countries to unauthenticated visitors.
app.MapGet("/access/available", (HttpContext http, string scenario, ScenarioCatalog catalog, AccountStore accounts) =>
{
    if (catalog.Get(scenario) is null) return Results.NotFound();
    using var store = new AtlasStore(catalog, accounts, scenario);
    var matching = store.Snapshot().Countries
        .Where(c => accounts.HasCountryAccess(c.Name, http.Request.Cookies[AccountStore.CountryCookieName(c.Name)]))
        .Select(c => c.Name).ToArray();
    return Results.Ok(matching);
});

app.MapPost("/access/unlock", async (HttpContext http, AccountStore accounts, ScenarioCatalog catalog,
    Microsoft.AspNetCore.Antiforgery.IAntiforgery antiforgery) =>
{
    try { await antiforgery.ValidateRequestAsync(http); }
    catch (Microsoft.AspNetCore.Antiforgery.AntiforgeryValidationException) { return Results.BadRequest("Invalid request token."); }
    var form = await http.Request.ReadFormAsync();
    string password = form["password"].ToString();
    string destination = form["returnUrl"].ToString();
    // Only allow a local return path for a registered scenario.
    if (!destination.StartsWith('/') || destination.StartsWith("//") || destination.Contains('\\'))
        return Results.BadRequest("Invalid return URL.");
    string route = destination.Split('?')[0];
    string? slug = ScenarioCatalog.SlugFromPath(route);
    if (slug is null || catalog.Get(slug) is null || !route.Equals("/" + slug + "/logistics", StringComparison.OrdinalIgnoreCase))
        return Results.BadRequest("Invalid scenario.");
    using var store = new AtlasStore(catalog, accounts, slug);
    var country = accounts.MatchCountryPassword(password, store.Snapshot().Countries.Select(c => c.Name));
    if (country is null)
        return Results.Redirect(destination.Contains('?') ? destination + "&accessError=1" : destination + "?accessError=1");
    http.Response.Cookies.Append(AccountStore.CountryCookieName(country), accounts.IssueAccessTicket(country), new CookieOptions {
        HttpOnly = true, Secure = http.Request.IsHttps, SameSite = SameSiteMode.Lax,
        IsEssential = true, Expires = DateTimeOffset.UtcNow.AddYears(5), Path = "/"
    });
    return Results.Redirect(destination);
}).RequireRateLimiting("country-password");

app.MapGet("/api/health", () => Results.Ok(new { status = "ok" }));
app.MapRazorComponents<App>().AddInteractiveServerRenderMode();
app.Run();
