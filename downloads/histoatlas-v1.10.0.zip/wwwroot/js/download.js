// Explicit download initiated by a Blazor button, without SPA navigation.
window.atlasDownloads = {
    async saveFile(fileName, streamReference) {
        if (!streamReference || typeof fileName !== "string" || !fileName.endsWith(".atlas.zip")) {
            throw new Error("Invalid scenario archive download.");
        }
        const buffer = await streamReference.arrayBuffer();
        if (!buffer || buffer.byteLength === 0) {
            throw new Error("Scenario archive is empty.");
        }
        const blob = new Blob([buffer], { type: "application/zip" });
        const url = URL.createObjectURL(blob);
        try {
            const link = document.createElement("a");
            link.href = url;
            link.download = fileName;
            link.style.display = "none";
            document.body.appendChild(link);
            link.click();
            link.remove();
        } finally {
            // Delay revocation so the browser has time to start downloading.
            setTimeout(() => URL.revokeObjectURL(url), 60000);
        }
    }
};
