window.atlasCountryAccess = {
    available: async function(scenario) {
        try {
            const response = await fetch('/access/available?scenario=' + encodeURIComponent(scenario),
                {credentials:'same-origin', cache:'no-store'});
            return response.ok ? await response.json() : [];
        } catch { return []; }
    },
    check: async function(country) {
        try {
            const response = await fetch('/access/check?country=' + encodeURIComponent(country),
                {credentials:'same-origin', cache:'no-store'});
            return response.ok && (await response.json()).allowed === true;
        } catch { return false; }
    }
};
