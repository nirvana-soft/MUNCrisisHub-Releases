// HistoAtlas raster viewer. The native base-map resolution anchors every overlay.
// One pointer pans; two pointers pinch to zoom around their moving midpoint.
const instances = new Map();

function syncDimensions(s) {
  const base = s.stage.querySelector('img.layer-base');
  const src = base?.currentSrc || base?.getAttribute('src') || '';
  if (src !== s.baseSrc) {
    s.baseSrc = src;
    s.zoom = 1;
    s.x = 0;
    s.y = 0;
    s.pointers.clear();
  }
  const w = base?.naturalWidth || (base ? s.mapWidth : s.frame.clientWidth);
  const h = base?.naturalHeight || (base ? s.mapHeight : s.frame.clientHeight);
  if (w > 0 && h > 0) {
    s.mapWidth = w;
    s.mapHeight = h;
    s.stage.style.width = `${w}px`;
    s.stage.style.height = `${h}px`;
  }
  render(s);
}

function currentScale(s) {
  return Math.min(Math.max(1, s.frame.clientWidth) / s.mapWidth,
                  Math.max(1, s.frame.clientHeight) / s.mapHeight) * s.zoom;
}

function render(s) {
  const scale = currentScale(s);
  s.scale = scale;
  s.left = (s.frame.clientWidth - s.mapWidth * scale) / 2 + s.x;
  s.top = (s.frame.clientHeight - s.mapHeight * scale) / 2 + s.y;
  // This calculation requires transform-origin: 0 0 (set in CSS).
  s.stage.style.transform = `translate(${s.left}px, ${s.top}px) scale(${scale})`;
}

function zoomAt(s, next, localX, localY) {
  const previousScale = currentScale(s);
  const imageX = (localX - s.left) / previousScale;
  const imageY = (localY - s.top) / previousScale;
  s.zoom = Math.max(0.6, Math.min(8, next));
  const scale = currentScale(s);
  s.x = localX - (s.frame.clientWidth - s.mapWidth * scale) / 2 - imageX * scale;
  s.y = localY - (s.frame.clientHeight - s.mapHeight * scale) / 2 - imageY * scale;
  render(s);
}

function firstTwo(pointers) {
  return [...pointers.values()].slice(0, 2);
}

function pinchMetrics(points) {
  const [a, b] = points;
  return { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2,
           distance: Math.hypot(b.x - a.x, b.y - a.y) };
}

function updateStatus(s, clientX, clientY) {
  if (!s.status) return;
  const rect = s.frame.getBoundingClientRect();
  const imageX = (clientX - rect.left - s.left) / Math.max(0.001, s.scale);
  const imageY = (clientY - rect.top - s.top) / Math.max(0.001, s.scale);
  s.status.textContent = `X ${Math.round(100 * imageX / s.mapWidth)}% · Y ${Math.round(100 * imageY / s.mapHeight)}%   |   ${Math.round(s.zoom * 100)}% ZOOM`;
}

function fullscreenActive(s) {
  return document.fullscreenElement === s.panel || s.panel.classList.contains('atlas-fullscreen-fallback');
}

function updateFullscreenButton(s) {
  const button = s.panel.querySelector('[data-atlas-fullscreen]');
  if (!button) return;
  const active = fullscreenActive(s);
  button.textContent = active ? '⤢' : '⛶';
  button.title = active ? 'Exit fullscreen map' : 'Fullscreen map';
  button.setAttribute('aria-label', button.title);
  button.setAttribute('aria-pressed', String(active));
}

function leaveFallback(s) {
  if (!s.panel.classList.contains('atlas-fullscreen-fallback')) return;
  s.panel.classList.remove('atlas-fullscreen-fallback');
  document.body.style.overflow = s.originalBodyOverflow ?? '';
  s.originalBodyOverflow = null;
  updateFullscreenButton(s);
  render(s);
}

async function toggleFullscreen(s) {
  if (s.panel.classList.contains('atlas-fullscreen-fallback')) {
    leaveFallback(s);
    return;
  }
  if (document.fullscreenElement === s.panel) {
    if (document.exitFullscreen) await document.exitFullscreen();
    return;
  }
  if (document.fullscreenElement) {
    // Do not take over fullscreen from an unrelated element.
    return;
  }
  if (s.panel.requestFullscreen && document.fullscreenEnabled !== false) {
    try {
      await s.panel.requestFullscreen();
      updateFullscreenButton(s);
      render(s);
      return;
    } catch (_) { /* iOS Safari / permissions: use CSS fallback. */ }
  }
  s.originalBodyOverflow = document.body.style.overflow;
  document.body.style.overflow = 'hidden';
  s.panel.classList.add('atlas-fullscreen-fallback');
  updateFullscreenButton(s);
  render(s);
}

export function setupMap(frameId, stageId, statusId) {
  const frame = document.getElementById(frameId);
  const stage = document.getElementById(stageId);
  const status = document.getElementById(statusId);
  if (!frame || !stage) return;
  const old = instances.get(frameId);
  if (old) disposeMap(frameId);
  const panel = frame.closest('.map-panel');
  if (!panel) return;
  const s = {
    frame, stage, panel, status,
    baseSrc: '', mapWidth: Math.max(1, frame.clientWidth),
    mapHeight: Math.max(1, frame.clientHeight),
    x: 0, y: 0, zoom: 1, left: 0, top: 0, scale: 1,
    pointers: new Map(), originalBodyOverflow: null,
    controller: new AbortController()
  };
  instances.set(frameId, s);
  const { signal } = s.controller;

  stage.addEventListener('load', e => {
    if (e.target instanceof HTMLImageElement && e.target.classList.contains('layer-base')) syncDimensions(s);
  }, { capture: true, signal });
  s.mutationObserver = new MutationObserver(() => syncDimensions(s));
  s.mutationObserver.observe(stage, { subtree: true, childList: true,
    attributes: true, attributeFilter: ['src'] });
  s.resizeObserver = new ResizeObserver(() => {
    if (!stage.querySelector('img.layer-base')) syncDimensions(s);
    else render(s);
  });
  s.resizeObserver.observe(frame);

  frame.addEventListener('pointerdown', e => {
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    if (e.pointerType === 'touch') e.preventDefault();
    if (s.pointers.size >= 2) return;
    s.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    try { frame.setPointerCapture(e.pointerId); } catch (_) { /* optional */ }
    frame.classList.add('dragging');
  }, { signal });

  frame.addEventListener('pointermove', e => {
    if (s.pointers.has(e.pointerId)) {
      if (e.pointerType === 'touch') e.preventDefault();
      const previous = s.pointers.get(e.pointerId);
      const before = s.pointers.size === 2 ? pinchMetrics(firstTwo(s.pointers)) : null;
      s.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (s.pointers.size === 1) {
        s.x += e.clientX - previous.x;
        s.y += e.clientY - previous.y;
        render(s);
      } else if (before) {
        const after = pinchMetrics(firstTwo(s.pointers));
        const rect = frame.getBoundingClientRect();
        // Zoom about the previous midpoint; then translate as both fingers move.
        if (before.distance > 1 && after.distance > 1) {
          zoomAt(s, s.zoom * after.distance / before.distance,
            before.x - rect.left, before.y - rect.top);
        }
        s.x += after.x - before.x;
        s.y += after.y - before.y;
        render(s);
      }
    }
    updateStatus(s, e.clientX, e.clientY);
  }, { signal, passive: false });

  const release = e => {
    s.pointers.delete(e.pointerId);
    if (!s.pointers.size) frame.classList.remove('dragging');
  };
  frame.addEventListener('pointerup', release, { signal });
  frame.addEventListener('pointercancel', release, { signal });
  frame.addEventListener('lostpointercapture', release, { signal });
  frame.addEventListener('wheel', e => {
    e.preventDefault();
    const rect = frame.getBoundingClientRect();
    zoomAt(s, s.zoom * (e.deltaY < 0 ? 1.12 : 1 / 1.12),
      e.clientX - rect.left, e.clientY - rect.top);
    updateStatus(s, e.clientX, e.clientY);
  }, { signal, passive: false });
  frame.addEventListener('dblclick', e => {
    e.preventDefault();
    const rect = frame.getBoundingClientRect();
    zoomAt(s, s.zoom * 1.6, e.clientX - rect.left, e.clientY - rect.top);
  }, { signal });
  s.fullscreenListener = () => { updateFullscreenButton(s); render(s); };
  document.addEventListener('fullscreenchange', s.fullscreenListener, { signal });
  s.escapeListener = e => { if (e.key === 'Escape') leaveFallback(s); };
  document.addEventListener('keydown', s.escapeListener, { signal });
  updateFullscreenButton(s);
  syncDimensions(s);
}

export async function mapControl(frameId, command) {
  const s = instances.get(frameId);
  if (!s) return;
  if (command === 'fullscreen') return toggleFullscreen(s);
  if (command === 'reset') { s.x = 0; s.y = 0; s.zoom = 1; render(s); return; }
  const factor = command === 'in' ? 1.25 : command === 'out' ? 0.8 : 1;
  zoomAt(s, s.zoom * factor, s.frame.clientWidth / 2, s.frame.clientHeight / 2);
}

export function disposeMap(frameId) {
  const s = instances.get(frameId);
  if (!s) return;
  s.controller.abort();
  s.resizeObserver?.disconnect();
  s.mutationObserver?.disconnect();
  leaveFallback(s);
  // On navigation, leave native fullscreen when possible.
  if (document.fullscreenElement === s.panel) document.exitFullscreen?.().catch(() => {});
  instances.delete(frameId);
}

// Admin map preview continues to use the base image's native proportions.
export function setupPreview(previewId) {
  const preview = document.getElementById(previewId);
  if (!preview) return;
  const updatePreview = () => {
    const image = preview.querySelector('img[alt="Base"]');
    if (image?.naturalWidth && image?.naturalHeight) {
      preview.style.aspectRatio = `${image.naturalWidth} / ${image.naturalHeight}`;
      preview.style.height = 'auto';
      preview.style.minHeight = '0';
    } else if (!image) {
      preview.style.aspectRatio = '';
      preview.style.height = '';
    }
  };
  preview.addEventListener('load', e => {
    if (e.target instanceof HTMLImageElement && e.target.alt === 'Base') updatePreview();
  }, true);
  const watcher = new MutationObserver(updatePreview);
  watcher.observe(preview, { childList: true, subtree: true,
    attributes: true, attributeFilter: ['src'] });
  updatePreview();
}
