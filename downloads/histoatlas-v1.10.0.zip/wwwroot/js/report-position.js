// Place deviance reports before revealing them. Never paint at 0,0.
// Also keeps the report inside the viewport after scrolling/resizing.
window.atlasReportPositioner = (() => {
    let pending = false;

    function position() {
        pending = false;
        const tooltip = document.querySelector('.atlas-floating-report');
        if (!tooltip) return;

        // The mobile report is a full-screen fixed dialog controlled by CSS.
        if (window.matchMedia('(max-width:760px)').matches) {
            tooltip.style.top = '';
            tooltip.style.left = '';
            tooltip.style.transform = '';
            tooltip.classList.add('atlas-positioned');
            return;
        }

        const cell = tooltip.closest('td');
        if (!cell) return;
        const anchor = cell.getBoundingClientRect();
        const margin = 9;
        const viewportW = document.documentElement.clientWidth;
        const viewportH = window.innerHeight;
        // Visibility:hidden still allows measurement of the natural dimensions.
        // Crucially, the report does not become visible during measurement.
        tooltip.style.top = '0px';
        tooltip.style.left = '0px';
        tooltip.style.transform = 'none';
        const bounds = tooltip.getBoundingClientRect();
        if (!bounds.width || !bounds.height) return;
        const scale = Math.min(1, (viewportH - 2 * margin) / Math.max(1, bounds.height));
        const w = bounds.width * scale;
        const h = bounds.height * scale;
        let x = anchor.right + 9;
        if (x + w > viewportW - margin) x = anchor.left - 9 - w;
        x = Math.max(margin, Math.min(x, viewportW - margin - w));
        let y = anchor.top - 8;
        y = Math.max(margin, Math.min(y, viewportH - margin - h));
        tooltip.style.left = `${Math.round(x)}px`;
        tooltip.style.top = `${Math.round(y)}px`;
        tooltip.style.transform = `scale(${scale})`;
        // Reveal only after layout measurements and final coordinates are applied.
        tooltip.classList.add('atlas-positioned');
    }

    function place() {
        // Called immediately after Blazor renders a report. Position synchronously
        // to prevent an extra animation frame of invisibility or stale placement.
        position();
    }
    function schedule() {
        if (pending) return;
        pending = true;
        requestAnimationFrame(position);
    }
    window.addEventListener('scroll', schedule, { passive: true, capture: true });
    window.addEventListener('resize', schedule, { passive: true });
    return { place };
})();
